# 安徽高职单招 PDF 批量下载

## 功能

批量抓取安徽招生考试网高职单招/对口招生相关页面中的 PDF 文件，并保存到本地目录。

## 安装依赖

```bash
pip install -r requirements.txt

##使用方式
打开 main.py
修改 save_dir
运行：
python main.py