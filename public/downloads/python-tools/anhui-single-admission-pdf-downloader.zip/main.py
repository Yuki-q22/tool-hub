import os
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

base = "https://www.ahzsks.cn/zyyx/"
domain = "https://www.ahzsks.cn"

save_dir = r"D:\Desktop\对口招生PDF"
os.makedirs(save_dir, exist_ok=True)

headers = {"User-Agent": "Mozilla/5.0"}

session = requests.Session()
session.headers.update(headers)


def clean_name(name):
    return re.sub(r'[\\/:*?"<>|]', "_", name)


def download_pdf(url, title):

    name = clean_name(title) + ".pdf"
    path = os.path.join(save_dir, name)

    if os.path.exists(path):
        print("已存在:", name)
        return

    r = session.get(url)

    with open(path, "wb") as f:
        f.write(r.content)

    print("下载:", name)


def parse_article(url, title):

    r = session.get(url)
    r.encoding = r.apparent_encoding

    soup = BeautifulSoup(r.text, "html.parser")

    pdf = soup.find("a", href=lambda x: x and x.endswith(".pdf"))

    if pdf:
        pdf_url = urljoin(domain, pdf["href"])
        download_pdf(pdf_url, title)
    else:
        print("未找到PDF:", title)


for page in [1, 2]:

    url = f"https://www.ahzsks.cn/zyyx/search2.jsp?c=231&pn={page}"

    print("抓取:", url)

    r = session.get(url)
    r.encoding = r.apparent_encoding

    soup = BeautifulSoup(r.text, "html.parser")

    articles = soup.select("a[href$='.htm']")

    for a in articles:

        href = a.get("href")
        title = a.get("title")

        if href:
            article_url = urljoin(base, href)
            parse_article(article_url, title)

print("完成")