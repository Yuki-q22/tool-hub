import os
import re
import pdfplumber
import pandas as pd

# 匹配：两位专业代码 + 名称 + 计划 + 语种 + 学制 + 学费
PROG_PATTERN = re.compile(
    r'^(\d{2})\s+'        # 专业代码（2 位）
    r'(.+?)\s+'           # 专业名称（非贪婪）
    r'(\d+)\s+'           # 计划(人)
    r'(\S+)\s+'           # 语种
    r'(\d+)\s+'           # 学制
    r'(\d+)$'             # 学费(元/年)
)

# 匹配：四位院校代码 + 名称 + 计划
INST_PATTERN = re.compile(
    r'^(\d{4})\s+'        # 院校代码（4 位）
    r'(.+?)\s+'           # 院校名称（第一行）
    r'(\d+)$'             # 计划(人)
)

# 用于跳过过渡标题行的关键词
HEADER_KEYWORDS = ['代码', '名称', '计划', '语种', '学制', '学费']

def extract_records(pdf_path):
    """
    按页、先左后右分栏裁剪，再对每行文本做正则匹配，
    跳过页码和多余标题行，支持院校名和专业名折行续接。
    """
    items = []
    basename = os.path.basename(pdf_path)
    previous_item = None   # 上一次匹配到的条目，用于续行拼接

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            w, h = page.width, page.height
            # 左半页和右半页的裁剪区域
            bboxes = [
                (0,   0,  w/2, h),
                (w/2, 0,   w,  h)
            ]
            for bbox in bboxes:
                area = page.crop(bbox)
                text = area.extract_text() or ""
                for raw_line in text.split('\n'):
                    line = raw_line.strip()
                    if not line:
                        continue

                    # 1) 跳过“第X页/…”这类页码行
                    if line.startswith('第') and '页' in line:
                        continue

                    # 2) 跳过多余的标题行（如果同时包含 >=4 个标题关键词）
                    if sum(1 for kw in HEADER_KEYWORDS if kw in line) >= 4:
                        continue

                    # 3) 匹配“专业行”
                    m_prog = PROG_PATTERN.match(line)
                    if m_prog:
                        code, name, plan, lang, dura, fee = m_prog.groups()
                        item = {
                            '代码': code,
                            '名称': name,
                            '计划(人)': plan,
                            '语种': lang,
                            '学制': dura,
                            '学费(元/年)': fee,
                            '来源文件': basename
                        }
                        items.append(item)
                        previous_item = item
                        continue

                    # 4) 匹配“院校行”
                    m_inst = INST_PATTERN.match(line)
                    if m_inst:
                        code, name, plan = m_inst.groups()
                        item = {
                            '代码': code,
                            '名称': name,
                            '计划(人)': plan,
                            '语种': '',
                            '学制': '',
                            '学费(元/年)': '',
                            '来源文件': basename
                        }
                        items.append(item)
                        previous_item = item
                        continue

                    # 5) 折行续接：既不匹配专业行也不匹配院校行，
                    #    并且不是新条目的开头，就当作上一条的“名称”续行
                    if previous_item and not re.match(r'^\d+', line):
                        previous_item['名称'] += ' ' + line
                        continue

                    # 其他行忽略

    return items

def batch_extract(input_path, output_csv):
    """
    支持单个 PDF 或目录批量处理，
    最终结果保存到 output_csv（UTF-8 BOM）。
    """
    # 判断单文件还是目录
    if os.path.isfile(input_path) and input_path.lower().endswith('.pdf'):
        pdfs = [input_path]
    elif os.path.isdir(input_path):
        pdfs = [
            os.path.join(input_path, f)
            for f in os.listdir(input_path)
            if f.lower().endswith('.pdf')
        ]
    else:
        raise ValueError(f"无效路径：{input_path}")

    all_items = []
    for pdf in pdfs:
        print(f"🗂 处理文件：{os.path.basename(pdf)}")
        recs = extract_records(pdf)
        print(f"  → 本文件匹配到 {len(recs)} 条记录")
        all_items.extend(recs)

    if not all_items:
        print("❌ 未匹配到任何记录，请检查正则或 PDF 排版。")
        return

    # pandas 会自动写一次标题行
    df = pd.DataFrame(all_items, columns=[
        '代码', '名称', '计划(人)', '语种', '学制', '学费(元/年)', '来源文件'
    ])
    df.to_csv(output_csv, index=False, encoding='utf-8-sig')
    print(f"✅ 完成，结果已保存到：{output_csv}")

if __name__ == '__main__':
    # 配置输入和输出路径
    INPUT_PATH = r"D:\Desktop\天津_已解除密码_8042.pdf"       # 或者目录：r"D:\Desktop\pdfs"
    OUTPUT_CSV = r"D:\Desktop\222.csv"
    batch_extract(INPUT_PATH, OUTPUT_CSV)
