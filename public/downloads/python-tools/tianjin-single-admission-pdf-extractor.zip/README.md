# 天津高职单招 PDF 提取

## 功能

从天津高职单招 PDF 中提取院校代码、院校名称、专业代码、专业名称、计划人数、语种、学制、学费等字段，并导出 CSV。

## 安装依赖

```bash
pip install -r requirements.txt

##使用方式
打开 main.py
修改：
INPUT_PATH = r"你的PDF文件或PDF目录"
OUTPUT_CSV = r"输出CSV路径"
运行：
python main.py
注意

该脚本依赖 PDF 的文本排版结构。如果 PDF 是扫描件或排版变化较大，需要调整正则或裁剪逻辑。