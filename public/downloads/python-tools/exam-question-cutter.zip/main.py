# -*- coding: utf-8 -*-
r"""
按题号批量截图 PDF 试题。

适用场景：
1. 已经手动把 Word / WPS / DOCX 转成 PDF。
2. 按顶层题号 1. 2. 3. ... 截图。
3. 不截“一、选择题”“二、选择题”“三、非选择题”等大标题。
4. 不截试卷头部、密级、考试标题、单独科目名、注意事项及其说明文字。
5. 小题（1）（2）（3）会保留在同一道题图片中。
6. 跨页题目会自动拼接成一张图，页间间隔较小。
7. 每张图片四周保留约 1cm 白边。

安装：
    pip install pymupdf pillow

使用方式：
    直接修改下面的 INPUT_PATH 和 OUTPUT_DIR，然后在 PyCharm 中运行本脚本。
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

try:
    import fitz  # PyMuPDF
except ImportError as exc:
    raise SystemExit("未安装 PyMuPDF，请先执行：pip install pymupdf") from exc

try:
    from PIL import Image
except ImportError as exc:
    raise SystemExit("未安装 Pillow，请先执行：pip install pillow") from exc

Image.MAX_IMAGE_PIXELS = None

# =========================================================
# 你主要只需要修改这里
# =========================================================

# 输入 PDF 文件路径；也可以填 PDF 文件夹路径。
INPUT_PATH = r"D:\Desktop\高考真题\（网络+收集版）2025年高考河北卷历史高考真题文档版（含答案）\2025年河北高考历史真题.pdf"

# 输出截图文件夹。
OUTPUT_DIR = r"D:\Desktop\题目截图"

# =========================================================
# 可调参数
# =========================================================

# 题号识别：只识别顶层题号 1. / 1．/ 1、，不识别（1）（2）小题。
QUESTION_RE = re.compile(r"^\s*([1-9]\d{0,2})[\.．、](?!\d)\s*")

# 大标题识别：一、选择题 / 二、选择题 / 三、非选择题 / 四、解答题 等。
# 这些标题会作为“上一题结束边界”，但不会单独截图，也不会被截入上一题。
SECTION_TITLE_RE = re.compile(
    r"^\s*"
    r"(?:"
    r"[一二三四五六七八九十]+\s*[、.．]\s*"
    r"(?:选择题|非选择题|填空题|实验题|解答题|计算题|综合题|问答题|作图题|判断题)"
    r"|"
    r"第\s*[一二三四五六七八九十]+\s*部分"
    r")"
)

# 试卷头部 / 密级 / 考试标题 / 注意事项识别。
# 用于避免“注意事项”下面的 1. 2. 3. 被误识别成真正题号。
PAPER_SECRET_RE = re.compile(
    r"(?:机密|绝密|秘密)\s*[★*]\s*启用前"
)

PAPER_TITLE_RE = re.compile(
    r"^\s*"
    r"(?:\d{4}\s*年)?"
    r"[\u4e00-\u9fa5]{0,20}"
    r"(?:省|市|自治区|全国)?"
    r".{0,20}"
    r"(?:"
    r"普通高中学业水平选择性考试"
    r"|普通高中学业水平考试"
    r"|普通高等学校招生全国统一考试"
    r"|普通高等学校招生考试"
    r"|高等学校招生考试"
    r"|高考"
    r"|学业水平选择性考试"
    r")"
    r"\s*$"
)

NOTICE_TITLE_RE = re.compile(r"^\s*(?:注意事项|考生须知|答题注意事项)\s*[:：]?\s*$")

# “注意事项”内部常见编号行。
NOTICE_ITEM_RE = re.compile(
    r"^\s*\d{1,2}[\.．、]\s*"
    r"(?:"
    r"答卷前"
    r"|答题前"
    r"|回答选择题时"
    r"|回答非选择题时"
    r"|考试结束后"
    r"|考试结束"
    r"|请将"
    r"|用铅笔"
    r"|用黑色字迹"
    r"|将答案"
    r"|本试卷"
    r"|本卷"
    r"|作答"
    r"|考生"
    r")"
)

# 注意事项续行关键词。用于处理“改动，用橡皮擦干净后……”这类不带编号的续行。
NOTICE_KEYWORDS = (
    "姓名",
    "考生号",
    "考场号",
    "座位号",
    "准考证号",
    "答题卡",
    "答题纸",
    "答案标号",
    "用铅笔",
    "用黑色字迹",
    "橡皮擦",
    "橡皮",
    "修改液",
    "修正带",
    "本试卷上无效",
    "试卷上无效",
    "一并交回",
    "交回",
    "答卷前",
    "答题前",
    "回答选择题",
    "回答非选择题",
    "考试结束",
)

# 单独成行的科目名。只在“版心中间、单独一行”时排除，避免误删题干里的普通词。
SUBJECT_NAMES = {
    "语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治",
    "思想政治", "道德与法治", "文科综合", "理科综合", "综合",
}

# 输出清晰度。240 比较均衡，300 更清晰但文件更大。
DEFAULT_DPI = 240

# 每道题最终图片四周白边，单位 cm。
EDGE_CM = 1.0

# 跨页拼接处内部间隔，单位 cm。越小，跨页题上下页内容越紧凑。
INNER_GAP_CM = 0.12

# 裁图时额外保留一点点，避免文字边缘被切掉，单位 pt。
SAFE_CLIP_PT = 2.0

# 题目结束边界前额外往上收一点，避免把下一题第一行截进去。
# 如果仍然截到下一题，改大到 10 或 12；如果最后一行被切掉，改小到 4。
END_BEFORE_BOUNDARY_PT = 8.0

# 页眉页脚忽略范围。PDF 有页眉页脚时可以改成 0.4 / 0.5。
IGNORE_TOP_CM = 0.0
IGNORE_BOTTOM_CM = 0.0

# 是否只处理 PDF。建议保持 True。
PDF_ONLY = True


@dataclass
class QuestionStart:
    qno: int
    page_index: int
    y: float
    x: float
    text: str


@dataclass
class SectionStart:
    page_index: int
    y: float
    x: float
    text: str


@dataclass
class Boundary:
    page_index: int
    y: float
    kind: str  # question / section / end
    text: str = ""


@dataclass
class Segment:
    page_index: int
    rect: fitz.Rect


def cm_to_pt(cm: float) -> float:
    return cm / 2.54 * 72.0


def cm_to_px(cm: float, dpi: int) -> int:
    return max(0, int(round(cm / 2.54 * dpi)))


def norm_text(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def compact_text(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def is_section_title(text: str) -> bool:
    return bool(SECTION_TITLE_RE.match(norm_text(text)))


def is_centered_single_subject_line(text: str, rect: fitz.Rect, page_rect: fitz.Rect) -> bool:
    """
    判断是否为单独成行的科目名，如“历史”“物理”。
    只在位置接近页面中部、内容很短时排除，避免误删题干中的普通词。
    """
    t = compact_text(text)
    if t not in SUBJECT_NAMES:
        return False

    page_width = page_rect.width
    line_center = (rect.x0 + rect.x1) / 2
    page_center = page_width / 2

    # 科目标题通常位于页面横向中部，且宽度较短。
    if abs(line_center - page_center) > page_width * 0.25:
        return False
    if rect.width > page_width * 0.35:
        return False

    return True


def is_paper_meta_line(text: str, rect: fitz.Rect, page_rect: fitz.Rect) -> bool:
    """
    识别不应被截入题目图片的试卷公共内容。
    包括：密级、试卷标题、单独科目名、注意事项标题、注意事项说明行。
    """
    t = norm_text(text)
    ct = compact_text(t)

    if not t:
        return True

    if PAPER_SECRET_RE.search(ct):
        return True

    if PAPER_TITLE_RE.match(t):
        return True

    if NOTICE_TITLE_RE.match(t):
        return True

    if NOTICE_ITEM_RE.match(t):
        return True

    if is_centered_single_subject_line(t, rect, page_rect):
        return True

    # “注意事项”的续行。尽量只过滤明显答题说明，避免影响普通题干。
    if any(keyword in t for keyword in NOTICE_KEYWORDS):
        return True

    return False


def update_notice_state(
    text: str,
    rect: fitz.Rect,
    page_rect: fitz.Rect,
    in_notice: bool,
) -> Tuple[bool, bool]:
    """
    返回：
        excluded: 当前行是否需要排除
        new_in_notice: 当前行之后是否仍处于注意事项区域

    作用：
    1. 防止“注意事项”中的 1. 2. 3. 被识别为真实题号；
    2. 防止注意事项续行被截入图片；
    3. 遇到真正题号或大标题时自动退出注意事项区域。
    """
    t = norm_text(text)

    if NOTICE_TITLE_RE.match(t):
        return True, True

    if is_section_title(t):
        return True, False

    if in_notice:
        # 如果遇到真正题号，并且不是注意事项编号行，说明注意事项结束。
        if QUESTION_RE.match(t) and not NOTICE_ITEM_RE.match(t):
            return False, False

        # 注意事项区域内，默认排除，直到遇到真正题号或大标题。
        return True, True

    if is_paper_meta_line(t, rect, page_rect):
        # 遇到注意事项编号行，也进入注意事项状态，便于继续排除后续换行。
        if NOTICE_ITEM_RE.match(t):
            return True, True
        return True, False

    return False, False


def is_before_or_same(a_page: int, a_y: float, b_page: int, b_y: float) -> bool:
    if a_page != b_page:
        return a_page < b_page
    return a_y <= b_y


def is_after(a_page: int, a_y: float, b_page: int, b_y: float, min_gap: float = 1.0) -> bool:
    if a_page != b_page:
        return a_page > b_page
    return a_y > b_y + min_gap


def get_text_lines(page: fitz.Page) -> List[Tuple[fitz.Rect, str]]:
    """返回页面文本行 bbox 和文本。"""
    data = page.get_text("dict")
    lines: List[Tuple[fitz.Rect, str]] = []

    for block in data.get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            text = "".join(span.get("text", "") for span in spans)
            text = norm_text(text)
            if not text:
                continue
            rect = fitz.Rect(line.get("bbox"))
            lines.append((rect, text))

    lines.sort(key=lambda item: (round(item[0].y0, 1), item[0].x0))
    return lines


def detect_question_starts(doc: fitz.Document) -> List[QuestionStart]:
    """识别顶层题号。"""
    raw: List[QuestionStart] = []

    for page_index in range(doc.page_count):
        page = doc[page_index]
        page_rect = page.rect
        in_notice = False

        for rect, text in get_text_lines(page):
            excluded, in_notice = update_notice_state(
                text=text,
                rect=rect,
                page_rect=page_rect,
                in_notice=in_notice,
            )
            if excluded:
                continue

            if is_section_title(text):
                continue

            m = QUESTION_RE.match(text)
            if not m:
                continue

            qno = int(m.group(1))
            raw.append(
                QuestionStart(
                    qno=qno,
                    page_index=page_index,
                    y=rect.y0,
                    x=rect.x0,
                    text=text,
                )
            )

    # 去重 + 过滤明显倒序误识别。
    filtered: List[QuestionStart] = []
    for st in raw:
        if filtered:
            prev = filtered[-1]
            same_pos = (
                st.page_index == prev.page_index
                and abs(st.y - prev.y) < 6
                and abs(st.x - prev.x) < 20
            )
            if st.qno == prev.qno and same_pos:
                continue

            # 正常试卷题号应递增。正文中如果误识别到较小数字，跳过。
            if st.qno < prev.qno:
                continue

            # 同一题号在后面再次出现，多数是页眉/解析/误识别，跳过。
            if st.qno == prev.qno and not same_pos:
                continue

        filtered.append(st)

    return filtered


def detect_section_starts(doc: fitz.Document) -> List[SectionStart]:
    """识别大标题位置，如 二、选择题 / 三、非选择题。"""
    sections: List[SectionStart] = []

    for page_index in range(doc.page_count):
        page = doc[page_index]
        page_rect = page.rect
        in_notice = False

        for rect, text in get_text_lines(page):
            excluded, in_notice = update_notice_state(
                text=text,
                rect=rect,
                page_rect=page_rect,
                in_notice=in_notice,
            )
            if excluded and not is_section_title(text):
                continue

            if is_section_title(text):
                sections.append(
                    SectionStart(
                        page_index=page_index,
                        y=rect.y0,
                        x=rect.x0,
                        text=text,
                    )
                )

    # 去重：同一标题有时会被拆成相近行。
    filtered: List[SectionStart] = []
    for st in sections:
        if filtered:
            prev = filtered[-1]
            if st.page_index == prev.page_index and abs(st.y - prev.y) < 8:
                continue
        filtered.append(st)

    return filtered


def next_boundary_for_question(
    doc: fitz.Document,
    start: QuestionStart,
    next_question: Optional[QuestionStart],
    sections: Sequence[SectionStart],
) -> Boundary:
    """
    找当前题结束边界：
    1. 默认是下一道题开始处；
    2. 如果当前题和下一题之间出现大标题，则先以大标题作为结束边界。
    """
    candidates: List[Boundary] = []

    if next_question is not None:
        candidates.append(
            Boundary(
                page_index=next_question.page_index,
                y=next_question.y,
                kind="question",
                text=next_question.text,
            )
        )

    for sec in sections:
        if not is_after(sec.page_index, sec.y, start.page_index, start.y, min_gap=1.0):
            continue

        # 如果存在下一题，只取当前题和下一题之间的大标题。
        if next_question is not None:
            if not is_before_or_same(sec.page_index, sec.y, next_question.page_index, next_question.y):
                continue

        candidates.append(
            Boundary(
                page_index=sec.page_index,
                y=sec.y,
                kind="section",
                text=sec.text,
            )
        )

    if not candidates:
        last_page = doc[doc.page_count - 1]
        return Boundary(
            page_index=doc.page_count - 1,
            y=last_page.rect.height,
            kind="end",
            text="",
        )

    candidates.sort(key=lambda b: (b.page_index, b.y))
    return candidates[0]


def text_rect_inside_y(rect: fitz.Rect, y0: float, y1: float) -> bool:
    """文本行按中心点判断，避免下一题第一行边缘与裁剪边界相交后被截入。"""
    mid_y = (rect.y0 + rect.y1) / 2
    return y0 <= mid_y < y1


def rect_intersects_y(rect: fitz.Rect, y0: float, y1: float) -> bool:
    """图片/矢量图按相交判断。"""
    return rect.y1 > y0 and rect.y0 < y1


def rect_center_inside_any_y_interval(rect: fitz.Rect, intervals: Sequence[Tuple[float, float]]) -> bool:
    if not intervals:
        return False
    mid_y = (rect.y0 + rect.y1) / 2
    return any(y0 <= mid_y <= y1 for y0, y1 in intervals)


def union_rects(rects: Sequence[fitz.Rect]) -> fitz.Rect:
    if not rects:
        raise ValueError("rects 不能为空")
    u = fitz.Rect(rects[0])
    for r in rects[1:]:
        u |= fitz.Rect(r)
    return u


def content_rects_in_range(page: fitz.Page, y0: float, y1: float) -> List[fitz.Rect]:
    """取 y 范围内的正文、图片、矢量图形 bbox；主动排除大标题和试卷公共说明。"""
    rects: List[fitz.Rect] = []
    data = page.get_text("dict")
    page_rect = page.rect

    text_lines: List[Tuple[fitz.Rect, str]] = []
    image_rects: List[fitz.Rect] = []

    # 先收集文本行和图片块，保证文本按页面顺序处理，便于识别“注意事项”区域。
    for block in data.get("blocks", []):
        btype = block.get("type")

        if btype == 0:
            for line in block.get("lines", []):
                rect = fitz.Rect(line.get("bbox"))
                text = "".join(span.get("text", "") for span in line.get("spans", []))
                text = norm_text(text)
                if not text:
                    continue
                text_lines.append((rect, text))

        elif btype == 1:
            rect = fitz.Rect(block.get("bbox"))
            image_rects.append(rect)

    text_lines.sort(key=lambda item: (round(item[0].y0, 1), item[0].x0))

    excluded_y_intervals: List[Tuple[float, float]] = []
    in_notice = False

    for rect, text in text_lines:
        if not text_rect_inside_y(rect, y0, y1):
            continue

        excluded, in_notice = update_notice_state(
            text=text,
            rect=rect,
            page_rect=page_rect,
            in_notice=in_notice,
        )

        # 大标题不进入截图内容。
        if is_section_title(text):
            excluded = True

        if excluded:
            excluded_y_intervals.append((rect.y0 - 2.0, rect.y1 + 2.0))
            continue

        rects.append(rect)

    # 图片块：如果图片中心落在被排除文字区域内，则跳过，避免注意事项附近图片/装饰被带入。
    for rect in image_rects:
        if not rect_intersects_y(rect, y0, y1):
            continue
        if rect_center_inside_any_y_interval(rect, excluded_y_intervals):
            continue
        rects.append(rect)

    # 矢量图形，如坐标轴、线条、公式图形等。
    # 如果矢量图中心落在被排除文字区域内，则跳过。
    try:
        for drawing in page.get_drawings():
            rect = fitz.Rect(drawing.get("rect"))
            if rect.is_empty or rect.width < 1 or rect.height < 1:
                continue
            if not rect_intersects_y(rect, y0, y1):
                continue
            if rect_center_inside_any_y_interval(rect, excluded_y_intervals):
                continue
            rects.append(rect)
    except Exception:
        pass

    clean: List[fitz.Rect] = []
    for r in rects:
        if r.width < 1 or r.height < 1:
            continue
        clean.append(r)

    return clean


def build_segments_for_question(
    doc: fitz.Document,
    start: QuestionStart,
    boundary: Boundary,
    ignore_top_cm: float = 0.0,
    ignore_bottom_cm: float = 0.0,
) -> List[Segment]:
    start_page = start.page_index
    end_page = boundary.page_index
    segments: List[Segment] = []

    top_ignore_pt = cm_to_pt(ignore_top_cm)
    bottom_ignore_pt = cm_to_pt(ignore_bottom_cm)

    for page_index in range(start_page, end_page + 1):
        page = doc[page_index]
        page_rect = page.rect

        # 当前题第一页从题号行开始；跨页后续页从页顶有效正文开始。
        if page_index == start_page:
            y0 = max(0.0, start.y - 1.0)
        else:
            y0 = 0.0
            if ignore_top_cm > 0:
                y0 = max(y0, top_ignore_pt)

        # 边界页截止到下一题或大标题之前。
        if page_index == boundary.page_index:
            if boundary.kind == "end":
                y1 = page_rect.height
                if ignore_bottom_cm > 0:
                    y1 = min(y1, page_rect.height - bottom_ignore_pt)
            else:
                y1 = max(y0, boundary.y - END_BEFORE_BOUNDARY_PT)
        else:
            y1 = page_rect.height
            if ignore_bottom_cm > 0:
                y1 = min(y1, page_rect.height - bottom_ignore_pt)

        if y1 <= y0 + 2:
            continue

        rects = content_rects_in_range(page, y0, y1)
        if not rects:
            continue

        content = union_rects(rects) & page_rect
        if content.is_empty or content.width < 2 or content.height < 2:
            continue

        segments.append(Segment(page_index=page_index, rect=content))

    return segments


def pixmap_to_image(pix: fitz.Pixmap) -> Image.Image:
    if pix.alpha:
        mode = "RGBA"
    elif pix.n == 1:
        mode = "L"
    else:
        mode = "RGB"

    img = Image.frombytes(mode, (pix.width, pix.height), pix.samples)

    if img.mode == "RGBA":
        bg = Image.new("RGB", img.size, "white")
        bg.paste(img, mask=img.split()[-1])
        return bg

    if img.mode != "RGB":
        return img.convert("RGB")

    return img


def render_segment(page: fitz.Page, clip: fitz.Rect, dpi: int) -> Image.Image:
    pix = page.get_pixmap(clip=clip, dpi=dpi, alpha=False)
    return pixmap_to_image(pix)


def stitch_images(images: Sequence[Image.Image], edge_px: int, gap_px: int) -> Image.Image:
    if not images:
        raise ValueError("images 不能为空")

    content_width = max(img.width for img in images)
    content_height = sum(img.height for img in images) + gap_px * max(0, len(images) - 1)

    canvas = Image.new(
        "RGB",
        (content_width + edge_px * 2, content_height + edge_px * 2),
        "white",
    )

    y = edge_px
    for i, img in enumerate(images):
        canvas.paste(img, (edge_px, y))
        y += img.height
        if i != len(images) - 1:
            y += gap_px

    return canvas


def safe_filename(text: str, max_len: int = 42) -> str:
    text = re.sub(r"[\\/:*?\"<>|\r\n\t]", "_", text)
    text = re.sub(r"\s+", "", text)
    if len(text) > max_len:
        text = text[:max_len]
    return text or "question"


def crop_one_question(
    doc: fitz.Document,
    start: QuestionStart,
    boundary: Boundary,
    out_dir: Path,
    dpi: int,
    edge_cm: float,
    inner_gap_cm: float,
    ignore_top_cm: float,
    ignore_bottom_cm: float,
) -> Optional[Path]:
    segments = build_segments_for_question(
        doc,
        start,
        boundary,
        ignore_top_cm=ignore_top_cm,
        ignore_bottom_cm=ignore_bottom_cm,
    )

    if not segments:
        return None

    # 同一道题所有页片段使用同一横向裁剪范围，保证跨页拼接时左右对齐。
    global_x0 = min(seg.rect.x0 for seg in segments)
    global_x1 = max(seg.rect.x1 for seg in segments)

    images: List[Image.Image] = []
    page_nums: List[int] = []

    for seg in segments:
        page = doc[seg.page_index]

        clip = fitz.Rect(
            global_x0 - SAFE_CLIP_PT,
            seg.rect.y0 - SAFE_CLIP_PT,
            global_x1 + SAFE_CLIP_PT,
            seg.rect.y1 + SAFE_CLIP_PT,
        ) & page.rect

        if clip.is_empty or clip.width < 2 or clip.height < 2:
            continue

        images.append(render_segment(page, clip, dpi=dpi))
        page_nums.append(seg.page_index + 1)

    if not images:
        return None

    edge_px = cm_to_px(edge_cm, dpi)
    gap_px = cm_to_px(inner_gap_cm, dpi)
    final_img = stitch_images(images, edge_px=edge_px, gap_px=gap_px)

    pages_part = f"P{page_nums[0]}" if len(set(page_nums)) == 1 else f"P{page_nums[0]}-P{page_nums[-1]}"
    title_part = safe_filename(start.text)
    out_path = out_dir / f"题{start.qno:02d}_{pages_part}_{title_part}.png"
    final_img.save(out_path)
    return out_path


def write_detect_log(
    out_dir: Path,
    starts: Sequence[QuestionStart],
    sections: Sequence[SectionStart],
) -> None:
    log_path = out_dir / "_detected_questions.txt"
    with log_path.open("w", encoding="utf-8") as f:
        f.write("[题号识别结果]\n")
        for st in starts:
            f.write(
                f"题{st.qno:02d}\t第{st.page_index + 1}页"
                f"\ty={st.y:.1f}\tx={st.x:.1f}\t{st.text}\n"
            )

        f.write("\n[大标题识别结果：这些不会截图，也不会截入上一题]\n")
        for sec in sections:
            f.write(
                f"第{sec.page_index + 1}页\ty={sec.y:.1f}\tx={sec.x:.1f}\t{sec.text}\n"
            )


def process_pdf(
    src: Path,
    out_dir: Path,
    dpi: int = DEFAULT_DPI,
    edge_cm: float = EDGE_CM,
    inner_gap_cm: float = INNER_GAP_CM,
    ignore_top_cm: float = IGNORE_TOP_CM,
    ignore_bottom_cm: float = IGNORE_BOTTOM_CM,
) -> None:
    src = src.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if PDF_ONLY and src.suffix.lower() != ".pdf":
        raise ValueError(f"当前脚本为 PDF 版，请先把文件另存为 PDF。当前文件：{src}")

    doc = fitz.open(src)
    try:
        starts = detect_question_starts(doc)
        sections = detect_section_starts(doc)

        if not starts:
            raise RuntimeError(
                "没有识别到题号。请确认题号格式是 1. / 1． / 1、，且 PDF 不是纯扫描图片。"
            )

        write_detect_log(out_dir, starts, sections)
        print(f"识别到 {len(starts)} 道题。")
        print(f"识别到 {len(sections)} 个大标题边界。")
        print(f"识别详情：{out_dir / '_detected_questions.txt'}")

        made = 0
        for i, st in enumerate(starts):
            next_st = starts[i + 1] if i + 1 < len(starts) else None
            boundary = next_boundary_for_question(doc, st, next_st, sections)

            out_path = crop_one_question(
                doc,
                st,
                boundary,
                out_dir=out_dir,
                dpi=dpi,
                edge_cm=edge_cm,
                inner_gap_cm=inner_gap_cm,
                ignore_top_cm=ignore_top_cm,
                ignore_bottom_cm=ignore_bottom_cm,
            )

            if out_path:
                made += 1
                print(f"已导出：{out_path.name}")
            else:
                print(f"警告：题{st.qno:02d} 未导出，可能没有可裁剪内容。")

        print(f"完成：共导出 {made} 张图片。输出目录：{out_dir}")

    finally:
        doc.close()


def collect_inputs(input_path: Path) -> List[Path]:
    if input_path.is_file():
        return [input_path]

    if input_path.is_dir():
        return sorted(
            p for p in input_path.iterdir()
            if p.suffix.lower() == ".pdf" and not p.name.startswith("~$")
        )

    raise FileNotFoundError(f"路径不存在：{input_path}")


def main() -> None:
    input_path = Path(INPUT_PATH)
    base_out = Path(OUTPUT_DIR)

    inputs = collect_inputs(input_path)
    if not inputs:
        raise SystemExit("没有找到可处理的 PDF 文件。")

    multi = len(inputs) > 1

    for src in inputs:
        out_dir = base_out / src.stem if multi else base_out
        print("=" * 80)
        print(f"处理：{src}")
        print(f"输出目录：{out_dir}")

        process_pdf(
            src=src,
            out_dir=out_dir,
            dpi=DEFAULT_DPI,
            edge_cm=EDGE_CM,
            inner_gap_cm=INNER_GAP_CM,
            ignore_top_cm=IGNORE_TOP_CM,
            ignore_bottom_cm=IGNORE_BOTTOM_CM,
        )


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n错误：{e}", file=sys.stderr)
        sys.exit(1)