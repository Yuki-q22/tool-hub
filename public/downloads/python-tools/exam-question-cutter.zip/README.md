# 高考真题题目截图处理

## 功能

按题号批量截图 PDF 试题，支持跨页拼接，并尽量排除试卷头部、大标题、注意事项等内容。

## 安装依赖

```bash
pip install -r requirements.txt

##使用方式
先把 Word / WPS / DOCX 转成 PDF
打开 main.py
修改：
INPUT_PATH = r"你的PDF路径"
OUTPUT_DIR = r"截图输出目录"
运行：
python main.py
注意

当前脚本主要处理文本型 PDF。如果 PDF 是纯扫描图片，题号识别可能失败。