async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) throw new Error('未找到当前标签页');
  return tab;
}

function canInject(tab) {
  const url = tab && tab.url ? String(tab.url) : '';
  return /^(https?:|file:)/i.test(url);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendMessageWithRetry(tabId, message, attempts = 12) {
  let lastError = null;
  for (let i = 0; i < attempts; i += 1) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (err) {
      lastError = err;
      await sleep(120 + i * 60);
    }
  }
  throw lastError || new Error('发送消息失败');
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'CTC_PING' });
    return;
  } catch (err) {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
    await sendMessageWithRetry(tabId, { type: 'CTC_PING' }, 12);
  }
}

async function togglePanel() {
  const tab = await getActiveTab();
  if (!canInject(tab)) return;
  await ensureContentScript(tab.id);
  await sendMessageWithRetry(tab.id, { type: 'CTC_TOGGLE_PANEL' }, 12);
}

chrome.action.onClicked.addListener(() => {
  togglePanel().catch(err => {
    console.warn('[表格采集器] 打开面板失败：', err);
  });
});
