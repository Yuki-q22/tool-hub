// This file has been modified to reorganize the UI layout into a 4-step workflow:
// Step 1: 字段配置 (Field Configuration)
// Step 2: 表格选择 (Table Selection)
// Step 3: 数据采集 (Data Collection)
// Step 4: 数据导出 (Data Export)
//
// All functionality and logic remains unchanged - only the UI presentation has been reorganized.

(() => {
  'use strict';

  const EXT_ID = 'cascade-table-crawler-extension-root';
  const STORAGE_PREFIX = 'CTC_STATE_V1:';
  const HIDDEN_EXPORT_FIELDS = new Set(['抓取时间', '表格行号', '表格时间']);

  const DEFAULT_STATE = {
    filterRootSelector: '',
    tableRootSelector: '',
    groups: [],
    yearFilter: '',
    provinceFilter: '',
    skipAllOption: true,
    summaryOptionMode: 'skip',
    onlyAllGroupLabels: '科类,类别,招生类别',
    minDelay: 500,
    maxDelay: 1200,
    stableMs: 600,
    timeoutMs: 10000,
    maxRowsPerTable: 0,
    paginationEnabled: false,
    paginationNextSelector: '',
    paginationMaxPages: 50,
    keywords: '省份,年份,科类,类别,类型,批次,招生类型,专业类,计划类型',
    records: [],
    logs: [],
    completedKeys: [],
    lastCompletedCombo: '',
    resumeAfterCombo: null
  };

  let state = structuredCloneSafe(DEFAULT_STATE);
  let running = false;
  let stopped = false;
  let resumeContext = null;
  let uiOpen = false;
  let activeTab = 'flow';
  let shadowRoot = null;
  let previewLimit = 60;
  let globalStyleInserted = false;

  function structuredCloneSafe(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function getStorageKey() {
    return `${STORAGE_PREFIX}${location.origin}${location.pathname}`;
  }

  async function loadState() {
    const key = getStorageKey();
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        const result = await chrome.storage.local.get(key);
        const loaded = result[key];
        state = normalizeLoadedState(loaded);
        return;
      }
    } catch (err) {
      console.warn('[表格采集器] chrome.storage.local 读取失败，改用 localStorage', err);
    }

    try {
      const raw = localStorage.getItem(key);
      state = normalizeLoadedState(raw ? JSON.parse(raw) : null);
    } catch (err) {
      state = normalizeLoadedState(null);
    }
  }

  async function saveState() {
    const key = getStorageKey();
    const value = normalizeLoadedState(state);

    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await chrome.storage.local.set({ [key]: value });
        return;
      }
    } catch (err) {
      console.warn('[表格采集器] chrome.storage.local 保存失败，改用 localStorage', err);
    }

    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (err) {
      console.warn('[表格采集器] localStorage 保存失败', err);
    }
  }

  function normalizeLoadedState(loaded) {
    const next = { ...structuredCloneSafe(DEFAULT_STATE), ...(loaded || {}) };

    if (!Array.isArray(next.groups)) next.groups = [];
    if (!Array.isArray(next.records)) next.records = [];
    if (!Array.isArray(next.logs)) next.logs = [];
    if (!Array.isArray(next.completedKeys)) next.completedKeys = [];
    if (!next.resumeAfterCombo || typeof next.resumeAfterCombo !== 'object') next.resumeAfterCombo = null;

    next.records = next.records.map(removeHiddenExportFields);
    next.groups = next.groups
      .filter(g => g && typeof g === 'object')
      .map((g, idx) => ({
        label: normalizeText(g.label || `字段${idx + 1}`),
        selector: String(g.selector || '')
      }))
      .filter(g => g.label && g.selector);

    next.minDelay = Number(next.minDelay) || DEFAULT_STATE.minDelay;
    next.maxDelay = Number(next.maxDelay) || DEFAULT_STATE.maxDelay;
    next.stableMs = Number(next.stableMs) || DEFAULT_STATE.stableMs;
    next.timeoutMs = Number(next.timeoutMs) || DEFAULT_STATE.timeoutMs;
    next.maxRowsPerTable = Number(next.maxRowsPerTable) || 0;
    next.paginationEnabled = !!next.paginationEnabled;
    next.paginationNextSelector = String(next.paginationNextSelector || '');
    next.paginationMaxPages = Math.max(1, Number(next.paginationMaxPages) || DEFAULT_STATE.paginationMaxPages);
    next.onlyAllGroupLabels = String(next.onlyAllGroupLabels || '');
    if (!['skip', 'keep', 'only'].includes(next.summaryOptionMode)) {
      next.summaryOptionMode = next.skipAllOption ? 'skip' : 'keep';
    }
    next.skipAllOption = next.summaryOptionMode === 'skip';

    return next;
  }

  function removeHiddenExportFields(row) {
    const next = { ...(row || {}) };
    for (const key of HIDDEN_EXPORT_FIELDS) delete next[key];
    return next;
  }

  function nowText() {
    const d = new Date();
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function log(message) {
    const text = `[${nowText()}] ${message}`;
    state.logs.unshift(text);
    state.logs = state.logs.slice(0, 300);
    saveState();
    render();
    console.log('[表格采集器]', message);
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function rand(min, max) {
    min = Number(min) || 0;
    max = Number(max) || min;
    if (max < min) max = min;
    return Math.floor(min + Math.random() * (max - min + 1));
  }

  function normalizeText(text) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t\r\n]+/g, ' ')
      .trim();
  }

  function parseLabelList(text) {
    return String(text || '')
      .split(/[，,、\n\s]+/)
      .map(x => normalizeText(x))
      .filter(Boolean);
  }

  function isSummaryOptionText(text) {
    const t = normalizeText(text);
    if (!t) return false;
    if (/^(all)$/i.test(t)) return true;
    return /^(全部|不限|请选择|所有|全部科类|全部类别|全部类型|全部批次|全部专业类|全部招生类型)$/.test(t);
  }

  function shouldOnlySummaryForGroup(group) {
    if (!group) return false;
    const labels = parseLabelList(state.onlyAllGroupLabels);
    if (!labels.length) return false;
    if (labels.includes('*') || labels.includes('全部字段')) return true;

    const groupLabel = normalizeText(group.label || '');
    if (!groupLabel) return false;

    return labels.some(label => {
      if (!label) return false;
      return groupLabel === label || groupLabel.includes(label) || label.includes(groupLabel);
    });
  }

  function escapeHtml(text) {
    return String(text ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, s => `\\${s}`);
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.closest(`#${EXT_ID}`)) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    return true;
  }

  function getBySelector(selector) {
    if (!selector) return null;
    try {
      return document.querySelector(selector);
    } catch (err) {
      return null;
    }
  }

  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id && el.id !== EXT_ID && !/^cascade-table-crawler/.test(el.id)) {
      return `#${cssEscape(el.id)}`;
    }

    const parts = [];
    let node = el;

    while (node && node.nodeType === 1 && node !== document.body && node !== document.documentElement) {
      let part = node.nodeName.toLowerCase();

      if (node.classList && node.classList.length) {
        const classes = [...node.classList]
          .filter(c => c && !/^(active|selected|checked|current|hover)$/.test(c))
          .slice(0, 3)
          .map(c => `.${cssEscape(c)}`)
          .join('');
        part += classes;
      }

      const parent = node.parentElement;
      if (parent) {
        const sameTagSiblings = [...parent.children].filter(x => x.nodeName === node.nodeName);
        if (sameTagSiblings.length > 1) {
          const index = sameTagSiblings.indexOf(node) + 1;
          part += `:nth-of-type(${index})`;
        }
      }

      parts.unshift(part);
      node = node.parentElement;
      if (parts.length >= 8) break;
    }

    return parts.join(' > ');
  }

  function uniqueBy(arr, keyFn) {
    const seen = new Set();
    const out = [];
    for (const item of arr) {
      const key = keyFn(item);
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(item);
    }
    return out;
  }

  function uniquePrimitive(arr) {
    const seen = new Set();
    const out = [];
    for (const item of arr) {
      if (seen.has(item)) continue;
      seen.add(item);
      out.push(item);
    }
    return out;
  }

  function cloneCombo(combo) {
    return structuredCloneSafe(combo || {});
  }

  function makeComboKey(combo) {
    const ordered = state.groups.map(g => [normalizeText(g.label || ''), normalizeText(combo[g.label] || '')]);
    return JSON.stringify(ordered);
  }

  function comboEquals(a, b) {
    if (!a || !b) return false;
    return makeComboKey(a) === makeComboKey(b);
  }

  function isComboCompleted(combo) {
    return state.completedKeys.includes(makeComboKey(combo));
  }

  function markComboCompleted(combo) {
    const key = makeComboKey(combo);
    if (!state.completedKeys.includes(key)) state.completedKeys.push(key);
    state.lastCompletedCombo = comboToText(combo);
    state.resumeAfterCombo = cloneCombo(combo);
    saveState();
  }

  function comboToText(combo) {
    return Object.entries(combo || {}).map(([k, v]) => `${k}=${v}`).join(' / ') || '当前条件';
  }

  function prefixMatchesResume(combo, depth) {
    if (!resumeContext || !resumeContext.resumeAfterCombo) return false;

    for (let i = 0; i < depth; i++) {
      const label = state.groups[i]?.label;
      if (!label) continue;
      if (normalizeText(combo[label] || '') !== normalizeText(resumeContext.resumeAfterCombo[label] || '')) return false;
    }

    return true;
  }

  function rebuildCompletedKeysFromRecords() {
    if (!state.records.length || !state.groups.length) return;

    const keys = new Set(state.completedKeys || []);
    let lastCombo = null;

    for (const row of state.records) {
      const combo = {};
      let hasAnyGroupValue = false;

      for (const group of state.groups) {
        const label = group.label;
        combo[label] = Object.prototype.hasOwnProperty.call(row, label) ? String(row[label] ?? '') : '';
        if (combo[label]) hasAnyGroupValue = true;
      }

      if (hasAnyGroupValue) {
        keys.add(makeComboKey(combo));
        lastCombo = cloneCombo(combo);
      }
    }

    state.completedKeys = [...keys];
    if (!state.resumeAfterCombo && lastCombo) {
      state.resumeAfterCombo = lastCombo;
      state.lastCompletedCombo = comboToText(lastCombo);
    }

    saveState();
  }

  function resetProgressAndRecords() {
    state.records = [];
    state.completedKeys = [];
    state.lastCompletedCombo = '';
    state.resumeAfterCombo = null;
    saveState();
  }

  function parseYearFilter() {
    const raw = normalizeText(state.yearFilter);
    if (!raw) return new Set();

    const years = new Set();
    const parts = raw.split(/[,，、\s\n]+/).map(normalizeText).filter(Boolean);

    for (const part of parts) {
      const match = part.match(/\d{2,4}/);
      if (!match) continue;
      let year = match[0];
      if (year.length === 2) year = `20${year}`;
      if (/^20\d{2}$/.test(year)) years.add(year);
    }

    return years;
  }

  function extractYearFromText(text) {
    const t = normalizeText(text);
    const m4 = t.match(/20\d{2}/);
    if (m4) return m4[0];

    const m2 = t.match(/(?:^|[^\d])(\d{2})(?:年|$|[^\d])/);
    if (m2) return `20${m2[1]}`;

    return '';
  }

  function isProvinceGroup(group) {
    const label = normalizeText(group?.label || '');
    return /省份|省区|地区|区域/.test(label);
  }

  function parseProvinceFilter() {
    const raw = normalizeText(state.provinceFilter);
    if (!raw) return new Set();

    const provinces = new Set();
    const parts = raw.split(/[,，、\s\n]+/).map(normalizeText).filter(Boolean);

    for (const part of parts) {
      provinces.add(part);
    }

    return provinces;
  }

  function filterOptionsByProvinceIfNeeded(group, optionTexts) {
    if (!isProvinceGroup(group)) return optionTexts;
    const provinceSet = parseProvinceFilter();
    if (!provinceSet.size) return optionTexts;

    return optionTexts.filter(text => {
      return provinceSet.has(text) || [...provinceSet].some(p => text.includes(p));
    });
  }

  function isYearGroup(group) {
    const label = normalizeText(group?.label || '');
    return /年份|招生年份|年度|年/.test(label);
  }

  function filterOptionsByYearIfNeeded(group, optionTexts) {
    if (!isYearGroup(group)) return optionTexts;
    const yearSet = parseYearFilter();
    if (!yearSet.size) return optionTexts;

    return optionTexts.filter(text => {
      const year = extractYearFromText(text);
      return year && yearSet.has(year);
    });
  }

  function isBeforeInDom(a, b) {
    if (!a || !b || a === b) return false;
    return !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  function hasTitleNearTable(container, table) {
    if (!container || !table || !container.contains(table)) return false;

    const titleSelectors = [
      'caption', 'h1', 'h2', 'h3', 'h4', 'h5',
      '.title', '.tit', '.table-title', '.tableTitle', '.table_tit', '.caption', '.name', '.section-title',
      '[class*="title"]', '[class*="Title"]', '[class*="tit"]', '[class*="caption"]'
    ].join(',');

    const titleEls = [...container.querySelectorAll(titleSelectors)]
      .filter(isVisible)
      .filter(el => !el.closest('table'))
      .filter(el => isBeforeInDom(el, table))
      .filter(el => {
        const t = normalizeText(el.innerText || el.textContent || '');
        return t.length >= 2 && t.length <= 80;
      });

    if (titleEls.length) return true;

    let node = table;
    for (let depth = 0; depth < 3 && node && node !== container; depth++, node = node.parentElement) {
      let prev = node.previousElementSibling;
      let checked = 0;
      while (prev && checked < 4) {
        if (isVisible(prev) && !prev.closest('table')) {
          const t = normalizeText(prev.innerText || prev.textContent || '');
          const hasTable = prev.querySelector && prev.querySelector('table');
          if (!hasTable && t.length >= 2 && t.length <= 120) return true;
        }
        prev = prev.previousElementSibling;
        checked++;
      }
    }

    return false;
  }

  function scoreTableContainer(container, table) {
    const rect = container.getBoundingClientRect();
    const text = normalizeText(container.innerText || container.textContent || '');
    const tableCount = container.querySelectorAll ? container.querySelectorAll('table').length : 0;
    let score = 0;

    score += Math.max(0, text.length - 3000) / 20;
    score += Math.max(0, tableCount - 1) * 120;
    score += rect.width > window.innerWidth * 0.96 ? 90 : 0;
    score += rect.height > window.innerHeight * 0.92 ? 90 : 0;
    score += container === document.body || container === document.documentElement ? 1000 : 0;
    score -= hasTitleNearTable(container, table) ? 260 : 0;

    const cls = String(container.className || '').toLowerCase();
    if (/(table|list|content|main|wrap|section|box|result|score|data)/.test(cls)) score -= 30;
    if (/(page|body|container|layout)/.test(cls) && rect.width > window.innerWidth * 0.88) score += 40;

    return score;
  }


  function getTextBeforeTable(container, table) {
    if (!container || !table || !container.childNodes) return '';
    const parts = [];

    function walk(node) {
      if (!node || node === table) return false;
      if (node.nodeType === Node.TEXT_NODE) {
        parts.push(node.textContent || '');
        return true;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return true;
      const el = node;
      if (el.closest && (el.closest('table') || el.closest(`#${EXT_ID}`))) return true;
      if (el.contains && el.contains(table)) {
        for (const child of el.childNodes) {
          if (child === table || (child.nodeType === Node.ELEMENT_NODE && child.contains?.(table))) {
            if (child !== table) walk(child);
            return false;
          }
          walk(child);
        }
        return false;
      }
      parts.push(el.innerText || el.textContent || '');
      return true;
    }

    walk(container);
    return normalizeText(parts.join(' '));
  }

  function containsLikelyFilterArea(container, table) {
    if (!container || !table || container === table) return false;
    const beforeText = getTextBeforeTable(container, table);
    if (!beforeText) return false;

    const keywordHits = parseLabelList(state.keywords)
      .filter(k => k && beforeText.includes(k)).length;
    const commonHits = ['省份', '年份', '科类', '类别', '类型', '批次', '招生类型', '专业类', '计划类型', '查询', '筛选']
      .filter(k => beforeText.includes(k)).length;

    const controlsBefore = [...container.querySelectorAll('a,button,li,label,select,input,[role="button"],[role="option"],[role="tab"],.btn,.item,.option,.tab')]
      .filter(isVisible)
      .filter(el => !el.closest('table') && !el.closest(`#${EXT_ID}`))
      .filter(el => isBeforeInDom(el, table))
      .length;

    return (keywordHits >= 2 || commonHits >= 2) && controlsBefore >= 3;
  }

  function resolveTablePickTarget(el, options = {}) {
    if (!el || !(el instanceof Element)) return el;

    const includeTitle = options.includeTitle !== false;

    let table = el.closest('table');
    if (!table && el.querySelector) {
      const ownTables = [...el.querySelectorAll('table')].filter(isVisible);
      if (ownTables.length) {
        ownTables.sort((a, b) => {
          const as = a.querySelectorAll('tr').length * 100 + a.querySelectorAll('td,th').length;
          const bs = b.querySelectorAll('tr').length * 100 + b.querySelectorAll('td,th').length;
          return bs - as;
        });
        table = ownTables[0];
      }
    }

    if (!table || !isVisible(table)) {
      let node = el;
      while (node && node !== document.body) {
        if (node.querySelector) {
          const tables = [...node.querySelectorAll('table')].filter(isVisible);
          if (tables.length) {
            tables.sort((a, b) => {
              const as = a.querySelectorAll('tr').length * 100 + a.querySelectorAll('td,th').length;
              const bs = b.querySelectorAll('tr').length * 100 + b.querySelectorAll('td,th').length;
              return bs - as;
            });
            table = tables[0];
            break;
          }
        }
        node = node.parentElement;
      }
    }

    if (!table || !isVisible(table)) return el;
    if (!includeTitle) return table;

    const candidates = [];
    let node = table.parentElement;
    for (let depth = 0; depth < 8 && node && node !== document.body && node !== document.documentElement; depth++, node = node.parentElement) {
      if (!isVisible(node) || !node.contains(table)) continue;
      const text = normalizeText(node.innerText || node.textContent || '');
      if (text.length > 16000) continue;
      if (!hasTitleNearTable(node, table)) continue;
      if (containsLikelyFilterArea(node, table)) continue;
      candidates.push({ el: node, score: scoreTableContainer(node, table), depth });
    }

    if (candidates.length) {
      candidates.sort((a, b) => {
        if (a.score !== b.score) return a.score - b.score;
        return a.depth - b.depth;
      });
      return candidates[0].el;
    }

    return table;
  }

  function getOptionText(el) {
    return normalizeText(el?.innerText || el?.textContent || '');
  }

  function isOptionLikeElement(el) {
    if (!el || !(el instanceof Element)) return false;
    const tag = el.tagName;
    if (/^(A|BUTTON|LI|LABEL|OPTION)$/.test(tag)) return true;
    if (el.getAttribute('role') === 'button' || el.getAttribute('role') === 'option' || el.getAttribute('role') === 'tab') return true;
    const cls = String(el.className || '').toLowerCase();
    if (/(^|\s|_|-)(btn|item|option|tab|radio|checkbox|cell)(\s|_|-|$)/.test(cls)) return true;
    const style = window.getComputedStyle(el);
    if (style.cursor === 'pointer') return true;
    if (typeof el.onclick === 'function') return true;
    return false;
  }

  function countChildOptionLike(el) {
    if (!el || !el.querySelectorAll) return 0;
    return [...el.querySelectorAll('a,button,li,label,option,[role="button"],[role="option"],[role="tab"],.btn,.item,.option,.tab')]
      .filter(child => child !== el && isVisible(child))
      .filter(child => getOptionText(child))
      .filter(child => getOptionText(child).length <= 64)
      .length;
  }

  function resolveOptionClickTarget(el, groupEl = null) {
    if (!el || !(el instanceof Element)) return el;
    const originalText = getOptionText(el);
    if (!originalText) return el;

    let best = el;
    let node = el;

    while (node && node instanceof Element && node !== document.body && node !== document.documentElement) {
      if (groupEl && node === groupEl) break;
      if (!isVisible(node) || node.closest('table') || node.closest(`#${EXT_ID}`)) break;

      const text = getOptionText(node);
      const childCount = countChildOptionLike(node);
      const sameText = text === originalText;
      const compactText = text.length <= Math.max(64, originalText.length + 16);
      const optionLike = isOptionLikeElement(node);

      if (sameText && compactText && childCount <= 1) {
        best = node;
        if (optionLike) break;
      }

      if (optionLike && text.includes(originalText) && compactText && childCount <= 2) {
        best = node;
        break;
      }

      node = node.parentElement;
    }

    return best || el;
  }

  function getOptionElements(groupEl, group = null) {
    if (!groupEl || !isVisible(groupEl)) return [];

    const selector = [
      'a', 'button', 'li', 'label', '[role="button"]', '[role="option"]', '[role="tab"]',
      '.btn', '.item', '.option', '.tab', '.active', '.selected', 'span', 'div'
    ].join(',');

    let list = [...groupEl.querySelectorAll(selector)]
      .filter(isVisible)
      .filter(el => !el.closest('table'))
      .filter(el => !el.closest(`#${EXT_ID}`))
      .filter(el => {
        const text = getOptionText(el);
        if (!text) return false;
        if (text.length > 64) return false;
        if (/^(省份|年份|科类|类别|类型|批次|招生类型|专业类|计划类型|年度)[：:]?$/.test(text)) return false;
        return true;
      });

    list = list
      .map(el => resolveOptionClickTarget(el, groupEl))
      .filter(Boolean)
      .filter(isVisible)
      .filter(el => !el.closest('table'))
      .filter(el => !el.closest(`#${EXT_ID}`));

    list = list.filter(el => {
      const text = getOptionText(el);
      if (!text || text.length > 64) return false;
      const childCandidateCount = countChildOptionLike(el);
      if ((el.tagName === 'DIV' || el.tagName === 'SPAN') && childCandidateCount >= 2 && text.length > 8) return false;
      return true;
    });

    list = uniqueBy(list, el => `${getOptionText(el)}@@${cssPath(el)}`);

    const byText = new Map();
    for (const el of list) {
      const text = getOptionText(el);
      const prev = byText.get(text);
      if (!prev) {
        byText.set(text, el);
        continue;
      }
      const prevScore = (isOptionLikeElement(prev) ? 2 : 0) - countChildOptionLike(prev);
      const nextScore = (isOptionLikeElement(el) ? 2 : 0) - countChildOptionLike(el);
      if (nextScore > prevScore) byText.set(text, el);
    }
    list = [...byText.values()];

    const summaryList = list.filter(el => isSummaryOptionText(getOptionText(el)));
    const summaryMode = state.summaryOptionMode || (state.skipAllOption ? 'skip' : 'keep');

    if (summaryMode === 'only' && shouldOnlySummaryForGroup(group) && summaryList.length) {
      return summaryList;
    }

    if (summaryMode === 'skip' || summaryMode === 'only') {
      list = list.filter(el => !isSummaryOptionText(getOptionText(el)));
    }

    return list;
  }

  function getGroupOptionsByIndex(depth) {
    const group = state.groups[depth];
    if (!group) return [];
    const groupEl = getBySelector(group.selector);
    if (!groupEl) return [];

    return getOptionElements(groupEl, group)
      .map(el => ({ text: getOptionText(el), selector: cssPath(el) }))
      .filter(x => x.text);
  }

  function findOptionElement(depth, text) {
    const group = state.groups[depth];
    if (!group) return null;
    const groupEl = getBySelector(group.selector);
    if (!groupEl) return null;
    const opts = getOptionElements(groupEl, group);
    return opts.find(el => getOptionText(el) === text) || null;
  }

  function hasActiveClassToken(el) {
    const cls = String(el?.className || '').toLowerCase();
    if (!cls || /(^|[\s_-])inactive([\s_-]|$)/.test(cls)) return false;
    return /(^|[\s_-])(active|selected|checked|current|cur|on|focus)([\s_-]|$)/.test(cls);
  }

  function isActiveOption(el) {
    if (!el) return false;
    const optionText = getOptionText(el);
    const nodes = [el];

    let parent = el.parentElement;
    for (let i = 0; i < 2 && parent; i++, parent = parent.parentElement) {
      const parentText = getOptionText(parent);
      if (parentText === optionText && countChildOptionLike(parent) <= 1) nodes.push(parent);
    }

    for (const node of nodes) {
      if (!node) continue;
      if (hasActiveClassToken(node)) return true;
      if (node.getAttribute('aria-selected') === 'true') return true;
      if (node.getAttribute('aria-checked') === 'true') return true;
      if (node.getAttribute('aria-current') === 'true') return true;
      if (node.matches?.('input:checked')) return true;
    }

    return false;
  }

  function getOwnText(el) {
    if (!el || !el.childNodes) return '';
    const parts = [];
    for (const node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) parts.push(node.textContent || '');
    }
    return normalizeText(parts.join(' '));
  }

  function countOtherKeywordHits(text, currentKeyword) {
    const keywords = state.keywords.split(/[,，、\n]/).map(normalizeText).filter(Boolean);
    const current = normalizeText(currentKeyword);
    return keywords.filter(k => k && k !== current && normalizeText(text).includes(k)).length;
  }

  function isLikelyBadDetectContainer(el, text) {
    if (!el || !text) return true;
    if (el === document.body || el === document.documentElement) return true;
    if (el.closest('table')) return true;

    const tag = el.tagName;
    if (/^(HTML|BODY|HEADER|FOOTER|NAV|SCRIPT|STYLE)$/.test(tag)) return true;

    const cls = String(el.className || '').toLowerCase();
    const id = String(el.id || '').toLowerCase();
    if (/(breadcrumb|crumb|nav|menu|header|footer|sidebar|side-bar)/.test(cls + ' ' + id)) return true;

    if (/当前位置|网站首页|首页\s*>|招生信息|信息公开|联系我们|版权|copyright/i.test(text)) return true;
    return false;
  }

  function scoreGroupCandidate(candidate, keyword) {
    const { el, text, validOpts, labelEl, climb } = candidate;
    const own = normalizeText(getOwnText(labelEl || el));
    const optionCount = validOpts.length;
    const otherKeywordHits = countOtherKeywordHits(text, keyword);
    const rect = el.getBoundingClientRect();

    let score = 0;
    score += text.length / 8;
    score += Math.abs(optionCount - 8) * 4;
    score += Math.max(0, optionCount - 40) * 12;
    score += (climb || 0) * 18;
    score += otherKeywordHits * 160;

    if (own === keyword || own === `${keyword}：` || own === `${keyword}:`) score -= 260;
    if (own.startsWith(keyword)) score -= 90;
    if (new RegExp(`^${keyword}[：:\\s]*`).test(text)) score -= 45;

    if (rect.width > window.innerWidth * 0.92) score += 90;
    if (text.length > 900) score += 200;
    if (text.length > 1500) score += 500;
    if (optionCount > 90) score += 500;
    if (isLikelyBadDetectContainer(el, text)) score += 900;

    return score;
  }

  function buildDetectCandidatesFromLabel(root, keyword) {
    const candidates = [];
    const nodes = [...root.querySelectorAll('*')]
      .filter(isVisible)
      .filter(el => !el.closest('table'))
      .filter(el => !el.closest(`#${EXT_ID}`));

    for (const labelEl of nodes) {
      const own = getOwnText(labelEl);
      const inner = normalizeText(labelEl.innerText);
      const labelLooksRight =
        own === keyword ||
        own === `${keyword}：` ||
        own === `${keyword}:` ||
        new RegExp(`^${keyword}[：:\\s]*$`).test(own) ||
        (own.length <= 18 && own.includes(keyword)) ||
        (inner.length <= 28 && new RegExp(`^${keyword}[：:\\s]*`).test(inner));

      if (!labelLooksRight) continue;

      let node = labelEl;
      for (let climb = 0; climb <= 5 && node && node !== document.body; climb++, node = node.parentElement) {
        if (!isVisible(node) || node.closest('table')) break;
        const text = normalizeText(node.innerText);
        if (!text.includes(keyword)) continue;
        if (text.length > 2600) continue;

        const opts = getOptionElements(node, { label: keyword });
        const validOpts = opts.filter(o => {
          const t = getOptionText(o);
          return t && t !== keyword && !new RegExp(`^${keyword}[：:]?$`).test(t);
        });

        if (validOpts.length >= 2) {
          candidates.push({ el: node, text, validOpts, labelEl, climb });
        }
      }
    }

    return candidates;
  }

  function buildDetectCandidatesBroad(root, keyword) {
    const candidates = [];
    const all = [...root.querySelectorAll('*')]
      .filter(isVisible)
      .filter(el => {
        if (el.closest('table') || el.closest(`#${EXT_ID}`)) return false;
        const text = normalizeText(el.innerText);
        if (!text || !text.includes(keyword)) return false;
        if (text.length > 2200) return false;
        return true;
      });

    for (const el of all) {
      let node = el;
      for (let climb = 0; climb < 5 && node && node !== document.body; climb++, node = node.parentElement) {
        if (!isVisible(node) || node.closest('table')) break;
        const text = normalizeText(node.innerText);
        if (!text.includes(keyword) || text.length > 2200) continue;

        const opts = getOptionElements(node, { label: keyword });
        const validOpts = opts.filter(o => {
          const t = getOptionText(o);
          return t && t !== keyword && !t.includes(`${keyword}：`) && !t.includes(`${keyword}:`);
        });

        if (validOpts.length >= 2) candidates.push({ el: node, text, validOpts, labelEl: el, climb });
      }
    }

    return candidates;
  }

  function findBestGroupByKeyword(root, keyword) {
    const allCandidates = [
      ...buildDetectCandidatesFromLabel(root, keyword),
      ...buildDetectCandidatesBroad(root, keyword)
    ];

    if (!allCandidates.length) return null;

    const unique = uniqueBy(allCandidates, c => cssPath(c.el));

    unique.sort((a, b) => {
      const sa = scoreGroupCandidate(a, keyword);
      const sb = scoreGroupCandidate(b, keyword);
      if (sa !== sb) return sa - sb;
      if (a.validOpts.length !== b.validOpts.length) return b.validOpts.length - a.validOpts.length;
      return a.text.length - b.text.length;
    });

    const best = unique[0];
    if (!best || scoreGroupCandidate(best, keyword) >= 900) return null;
    return best.el;
  }

  function findTabGroup(root) {
    const all = [...root.querySelectorAll('*')].filter(isVisible).filter(el => !el.closest('table'));

    for (const el of all) {
      const text = normalizeText(el.innerText);
      if (!text) continue;
      if (text.includes('录取概况') && text.includes('分专业录取情况') && text.length < 240) {
        const opts = getOptionElements(el);
        const names = opts.map(o => getOptionText(o));
        if (names.includes('录取概况') && names.includes('分专业录取情况')) return el;
      }
    }

    return null;
  }

  function detectGroupLabel(el, index) {
    const text = normalizeText(el.innerText);
    const m = text.match(/([^\s：:]{1,14})[：:]/);
    if (m && m[1]) return m[1];
    if (text.includes('录取概况') && text.includes('分专业录取情况')) return '表格类型';
    if (/20\d{2}/.test(text)) return '年份';
    return `字段${index + 1}`;
  }

  function cleanupAutoDetectedGroups(groups, keywords) {
    const cleaned = [];
    const seen = new Set();

    for (const group of groups) {
      if (!group || !group.selector || !group.label) continue;
      const el = getBySelector(group.selector);
      if (!el) continue;
      const text = normalizeText(el.innerText);
      const opts = getOptionElements(el, group);
      if (opts.length < 2) continue;
      if (isLikelyBadDetectContainer(el, text)) continue;
      if (text.length > 2200 && countOtherKeywordHits(text, group.label) >= 2) continue;

      const key = group.selector;
      if (seen.has(key)) continue;
      seen.add(key);
      cleaned.push(group);
    }

    return cleaned.filter((group, idx) => {
      const el = getBySelector(group.selector);
      if (!el) return false;
      const text = normalizeText(el.innerText);
      const otherHits = countOtherKeywordHits(text, group.label);
      if (otherHits < 2) return true;

      const hasMorePrecisePeer = cleaned.some((peer, peerIdx) => {
        if (peerIdx === idx) return false;
        const peerEl = getBySelector(peer.selector);
        return peerEl && el !== peerEl && el.contains(peerEl);
      });

      return !hasMorePrecisePeer;
    });
  }

  function autoDetectGroups() {
    const root = getBySelector(state.filterRootSelector) || document.body;
    const keywords = state.keywords.split(/[,，、\n]/).map(normalizeText).filter(Boolean);
    const groups = [];

    for (const keyword of keywords) {
      const el = findBestGroupByKeyword(root, keyword);
      if (!el) continue;
      const selector = cssPath(el);
      if (groups.some(g => g.selector === selector)) continue;
      groups.push({ label: keyword, selector });
    }

    const shouldDetectTabGroup = keywords.some(k => /表格类型|录取概况|分专业录取情况/.test(k));
    if (shouldDetectTabGroup) {
      const tabGroup = findTabGroup(root);
      if (tabGroup) {
        const selector = cssPath(tabGroup);
        if (!groups.some(g => g.selector === selector)) groups.push({ label: '表格类型', selector });
      }
    }

    state.groups = cleanupAutoDetectedGroups(groups, keywords);
    state.completedKeys = [];
    state.lastCompletedCombo = '';
    state.resumeAfterCombo = null;
    saveState();
    log(`自动识别完成：${groups.length} 个字段组；字段组变化后已清空采集进度，结果未删除`);
  }

  function dispatchMouseSequence(el, x, y) {
    const common = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y };
    try {
      el.dispatchEvent(new PointerEvent('pointerover', common));
      el.dispatchEvent(new MouseEvent('mouseover', common));
      el.dispatchEvent(new PointerEvent('pointermove', common));
      el.dispatchEvent(new MouseEvent('mousemove', common));
      el.dispatchEvent(new PointerEvent('pointerdown', common));
      el.dispatchEvent(new MouseEvent('mousedown', common));
      el.dispatchEvent(new PointerEvent('pointerup', common));
      el.dispatchEvent(new MouseEvent('mouseup', common));
      el.dispatchEvent(new MouseEvent('click', common));
    } catch (err) {
      el.dispatchEvent(new MouseEvent('click', common));
    }
  }

  async function humanClick(el, options = {}) {
    if (!el) return;

    const target = options.rawTarget ? el : resolveOptionClickTarget(el, options.groupEl || null);
    if (!target) return;

    target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    await sleep(rand(120, 260));

    const rect = target.getBoundingClientRect();
    const x = rect.left + rect.width / 2 + rand(-3, 3);
    const y = rect.top + rect.height / 2 + rand(-3, 3);

    try { target.focus?.(); } catch (err) {}

    dispatchMouseSequence(target, x, y);

    try { target.click?.(); } catch (err) {}

    const fallbackParent = target.parentElement;
    if (fallbackParent && fallbackParent !== target && getOptionText(fallbackParent) === getOptionText(target) && countChildOptionLike(fallbackParent) <= 1) {
      try {
        const pr = fallbackParent.getBoundingClientRect();
        dispatchMouseSequence(fallbackParent, pr.left + pr.width / 2, pr.top + pr.height / 2);
        fallbackParent.click?.();
      } catch (err) {}
    }
  }

  function getPageSignature() {
    const root = getBySelector(state.tableRootSelector) || document.body;
    return normalizeText(root.innerText).slice(0, 5000);
  }

  function waitDomStable(timeoutMs, stableMs) {
    return new Promise(resolve => {
      let timer = null;
      let done = false;

      const finish = () => {
        if (done) return;
        done = true;
        observer.disconnect();
        clearTimeout(timer);
        resolve();
      };

      const resetTimer = () => {
        clearTimeout(timer);
        timer = setTimeout(finish, stableMs);
      };

      const observer = new MutationObserver(resetTimer);
      observer.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: true });

      resetTimer();
      setTimeout(finish, timeoutMs);
    });
  }

  async function clickAndWait(el, desc, options = {}) {
    const before = getPageSignature();
    await humanClick(el, options);
    await sleep(rand(state.minDelay, state.maxDelay));
    await waitDomStable(state.timeoutMs, state.stableMs);
    let after = getPageSignature();

    if (before === after && !isActiveOption(el)) {
      await humanClick(el, { ...options, rawTarget: true });
      await sleep(rand(Math.max(700, state.minDelay), Math.max(1400, state.maxDelay + 500)));
      await waitDomStable(state.timeoutMs, state.stableMs);
      after = getPageSignature();
    }

    if (before === after) await sleep(rand(300, 700));
    if (desc) log(`已点击：${desc}`);
  }

  function extractCurrentTableRows() {
    const tableRoot = getBySelector(state.tableRootSelector) || document.body;
    let tables = [];

    if (tableRoot.tagName === 'TABLE') {
      tables = [tableRoot];
    } else {
      tables = [...tableRoot.querySelectorAll('table')]
        .filter(isVisible)
        .filter(t => !t.closest(`#${EXT_ID}`));
    }

    if (tables.length) {
      tables.sort((a, b) => {
        const as = a.querySelectorAll('tr').length * 100 + a.querySelectorAll('td,th').length;
        const bs = b.querySelectorAll('tr').length * 100 + b.querySelectorAll('td,th').length;
        return bs - as;
      });
      return extractTableElement(tables[0]);
    }

    return extractPseudoTable(tableRoot);
  }

  function extractTableElement(table) {
    return [...table.querySelectorAll('tr')]
      .filter(isVisible)
      .map(tr => [...tr.querySelectorAll('th,td')].filter(isVisible).map(td => normalizeText(td.innerText)))
      .filter(row => row.some(Boolean));
  }

  function extractPseudoTable(root) {
    const rowSelectors = ['.el-table__row', '.ant-table-row', '.layui-table tr', '.table tr', '.list tr', '.tbody tr', '[class*="row"]'];

    for (const sel of rowSelectors) {
      const rows = [...root.querySelectorAll(sel)].filter(isVisible).filter(el => !el.closest(`#${EXT_ID}`));
      if (rows.length >= 2) {
        return rows.map(row => {
          const cells = [...row.querySelectorAll('td,th,.cell,[class*="cell"],span,div')]
            .filter(isVisible)
            .map(cell => normalizeText(cell.innerText))
            .filter(Boolean);
          return uniquePrimitive(cells);
        }).filter(row => row.length);
      }
    }

    return [];
  }


  function isDisabledLike(el) {
    if (!el || !(el instanceof Element)) return true;
    if (!isVisible(el)) return true;
    if (el.matches?.(':disabled,[disabled]')) return true;
    if (el.getAttribute('aria-disabled') === 'true') return true;
    const cls = String(el.className || '').toLowerCase();
    if (/(^|\s|_|-)(disabled|disable|unavailable|forbid|forbidden)(\s|_|-|$)/.test(cls)) return true;
    const parent = el.parentElement;
    if (parent) {
      const pcls = String(parent.className || '').toLowerCase();
      if (/(^|\s|_|-)(disabled|disable|unavailable|forbid|forbidden)(\s|_|-|$)/.test(pcls)) return true;
      if (parent.getAttribute('aria-disabled') === 'true') return true;
    }
    return false;
  }

  function resolvePaginationClickTarget(el) {
    if (!el || !(el instanceof Element)) return el;
    if (/^(A|BUTTON)$/.test(el.tagName)) return el;
    const direct = [...el.querySelectorAll('a,button,[role="button"]')]
      .filter(isVisible)
      .find(child => !isDisabledLike(child));
    return direct || el;
  }

  function getElementDistanceToTable(el) {
    const root = getBySelector(state.tableRootSelector) || document.body;
    const er = el.getBoundingClientRect();
    const rr = root.getBoundingClientRect();
    const vertical = Math.abs(er.top - rr.bottom);
    const horizontal = Math.abs((er.left + er.right) / 2 - (rr.left + rr.right) / 2);
    const afterBonus = er.top >= rr.top ? -300 : 0;
    return vertical + horizontal / 4 + afterBonus;
  }

  function looksLikeNextPageButton(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.closest(`#${EXT_ID}`) || el.closest('table')) return false;
    const text = normalizeText(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '');
    const cls = String(el.className || '').toLowerCase();
    const aria = String(el.getAttribute('aria-label') || '').toLowerCase();
    const title = String(el.getAttribute('title') || '').toLowerCase();
    const rel = String(el.getAttribute('rel') || '').toLowerCase();
    const token = `${cls} ${aria} ${title} ${rel}`;

    if (/上一页|上页|prev|previous|left|back/.test(`${text} ${token}`)) return false;
    if (/下一页|下页|下一条|下一个|next|right|forward/.test(`${text} ${token}`)) return true;
    if (/^(>|›|»|→)$/.test(text)) return true;
    if (/(pagination|pager|page).*(next)|next.*(pagination|pager|page)|ant-pagination-next|el-pagination__next|btn-next|page-next|next-page/.test(token)) return true;
    return false;
  }

  function findNextPageButton() {
    if (state.paginationNextSelector) {
      const picked = getBySelector(state.paginationNextSelector);
      if (picked && !isDisabledLike(picked)) return resolvePaginationClickTarget(picked);
      return null;
    }

    const selectors = [
      'a', 'button', 'li', 'span', 'div',
      '[role="button"]', '[aria-label]', '[title]',
      '.next', '.btn-next', '.page-next', '.next-page',
      '.ant-pagination-next', '.el-pagination__next', '.layui-laypage-next', '.ivu-page-next'
    ].join(',');

    const candidates = [...document.querySelectorAll(selectors)]
      .filter(isVisible)
      .filter(el => !isDisabledLike(el))
      .filter(looksLikeNextPageButton)
      .map(el => resolvePaginationClickTarget(el))
      .filter(el => el && !isDisabledLike(el));

    const unique = uniqueBy(candidates, el => cssPath(el));
    unique.sort((a, b) => getElementDistanceToTable(a) - getElementDistanceToTable(b));
    return unique[0] || null;
  }

  function getPaginationSignature() {
    const root = getBySelector(state.tableRootSelector) || document.body;
    return `${location.href}\n${normalizeText(root.innerText || root.textContent || '').slice(0, 8000)}`;
  }

  async function extractRecordsAcrossPages(combo) {
    const out = [];
    const seenPageSignatures = new Set();
    const maxPages = Math.max(1, Number(state.paginationMaxPages) || DEFAULT_STATE.paginationMaxPages);

    for (let pageIndex = 1; pageIndex <= maxPages; pageIndex++) {
      if (stopped) break;

      await waitDomStable(state.timeoutMs, state.stableMs);
      const signature = getPaginationSignature();
      if (seenPageSignatures.has(signature)) {
        log(`分页采集停止：检测到重复页面，当前组合=${comboToText(combo)}`);
        break;
      }
      seenPageSignatures.add(signature);

      const rows = extractCurrentTableRows();
      const records = rowsToRecords(rows, combo);
      out.push(...records);
      log(`分页采集：第 ${pageIndex} 页读取 ${records.length} 行`);

      if (!state.paginationEnabled) break;
      if (pageIndex >= maxPages) {
        log(`分页采集停止：已达到最大页数 ${maxPages}`);
        break;
      }

      const nextBtn = findNextPageButton();
      if (!nextBtn) break;

      const before = getPaginationSignature();
      await clickAndWait(nextBtn, `下一页（第 ${pageIndex + 1} 页）`, { rawTarget: true });
      await waitDomStable(state.timeoutMs, state.stableMs);
      const after = getPaginationSignature();

      if (before === after) {
        log('分页采集停止：点击下一页后表格内容未变化');
        break;
      }
    }

    return out;
  }

  function rowsToRecords(rows, combo) {
    if (!rows || !rows.length) return [];

    let header = rows[0];
    let dataRows = rows.slice(1);

    const headerLooksValid = header.length >= 2 && header.some(x => /省份|年份|科类|专业|名称|最高|最低|平均|位次|人数|批次|类型|分数|计划|代码|院校|学校/.test(x));

    if (!headerLooksValid) {
      const maxLen = Math.max(...rows.map(r => r.length));
      header = Array.from({ length: maxLen }, (_, i) => `列${i + 1}`);
      dataRows = rows;
    }

    header = normalizeHeaders(header);

    if (state.maxRowsPerTable > 0) dataRows = dataRows.slice(0, state.maxRowsPerTable);

    const out = [];
    for (const row of dataRows) {
      if (!row.some(Boolean)) continue;
      const obj = { ...combo };
      header.forEach((h, idx) => {
        if (!HIDDEN_EXPORT_FIELDS.has(h)) obj[h] = row[idx] == null ? '' : row[idx];
      });
      out.push(obj);
    }

    return out;
  }

  function normalizeHeaders(header) {
    const count = {};
    return header.map((h, i) => {
      let name = normalizeText(h) || `列${i + 1}`;
      count[name] = (count[name] || 0) + 1;
      if (count[name] > 1) name = `${name}_${count[name]}`;
      return name;
    });
  }

  async function startCrawler(mode) {
    if (running) {
      log('当前已有采集任务在运行');
      return;
    }

    syncInputsFromUI();

    if (!state.groups.length) autoDetectGroups();
    if (!state.groups.length) {
      log('未识别到字段组，请手动添加字段组');
      return;
    }

    if (mode === 'fresh') {
      resetProgressAndRecords();
      resumeContext = null;
      log('已清空已有结果和进度，开始采集');
    }

    if (mode === 'resume') {
      if (!state.resumeAfterCombo && state.records.length) rebuildCompletedKeysFromRecords();

      if (state.resumeAfterCombo) {
        resumeContext = {
          enabled: true,
          gateOpen: false,
          resumeAfterCombo: cloneCombo(state.resumeAfterCombo),
          resumeAfterKey: makeComboKey(state.resumeAfterCombo)
        };
        log(`继续采集：将从断点后继续，断点=${comboToText(state.resumeAfterCombo)}`);
      } else {
        resumeContext = { enabled: true, gateOpen: true, resumeAfterCombo: null, resumeAfterKey: '' };
        log('继续采集：未找到断点，将使用"跳过已完成组合"模式');
      }

      log(`当前保留 ${state.records.length} 行结果，已完成 ${state.completedKeys.length} 个组合`);
    }

    stopped = false;
    running = true;
    render();

    try {
      const yearSet = parseYearFilter();
      log(yearSet.size ? `年份筛选已启用：${[...yearSet].join('、')}` : '年份筛选未启用，将遍历全部年份');
      const summaryMode = state.summaryOptionMode || (state.skipAllOption ? 'skip' : 'keep');
      const onlyAllLabels = parseLabelList(state.onlyAllGroupLabels);
      if (summaryMode === 'only' && onlyAllLabels.length) {
        log(`汇总选项处理：${onlyAllLabels.join('、')} 字段组只采集"全部/不限"等汇总选项`);
      } else if (summaryMode === 'skip') {
        log('汇总选项处理：跳过全部/不限/请选择');
      } else {
        log('汇总选项处理：保留全部/不限/请选择');
      }
      log(`开始采集，字段组数量：${state.groups.length}`);
      await traverseGroups(0, {});

      if (stopped) {
        log(`已停止。当前保留 ${state.records.length} 行，已完成 ${state.completedKeys.length} 个组合，可继续采集`);
      } else {
        log(`采集完成，累计 ${state.records.length} 行，完成 ${state.completedKeys.length} 个组合`);
      }
    } catch (err) {
      console.error(err);
      log(`采集异常：${err.message || err}`);
    } finally {
      running = false;
      stopped = false;
      resumeContext = null;
      await saveState();
      render();
    }
  }

  async function traverseGroups(depth, combo) {
    if (stopped) return;

    if (depth >= state.groups.length) {
      if (resumeContext && resumeContext.enabled && !resumeContext.gateOpen) {
        if (comboEquals(combo, resumeContext.resumeAfterCombo)) {
          resumeContext.gateOpen = true;
          log(`已定位到断点组合，后续开始继续采集：${comboToText(combo)}`);
        }
        return;
      }

      if (isComboCompleted(combo)) {
        log(`跳过已完成组合：${comboToText(combo)}`);
        return;
      }

      await waitDomStable(state.timeoutMs, state.stableMs);
      if (stopped) return;

      const records = await extractRecordsAcrossPages(combo);
      if (!records.length) {
        markComboCompleted(combo);
        log(`无表格数据，已标记完成：${comboToText(combo)}`);
        return;
      }

      state.records.push(...records);
      state.records = state.records.map(removeHiddenExportFields);
      markComboCompleted(combo);
      await saveState();
      log(`抓取 ${records.length} 行：${comboToText(combo)}`);
      return;
    }

    const group = state.groups[depth];
    const options = getGroupOptionsByIndex(depth);

    if (!options.length) {
      log(`字段组无可选项，跳过：${group.label}`);
      await traverseGroups(depth + 1, { ...combo, [group.label]: '' });
      return;
    }

    let optionTexts = uniquePrimitive(options.map(o => o.text).filter(Boolean));
    optionTexts = filterOptionsByYearIfNeeded(group, optionTexts);
    optionTexts = filterOptionsByProvinceIfNeeded(group, optionTexts);

    if (!optionTexts.length) {
      if (isYearGroup(group)) {
        log(`年份筛选后无可遍历年份：${group.label}，请检查页面年份选项或年份筛选输入`);
      } else if (isProvinceGroup(group)) {
        log(`省份筛选后无可遍历省份：${group.label}，请检查页面省份选项或省份筛选输入`);
      } else {
        log(`字段组无可遍历选项：${group.label}`);
      }
      return;
    }

    let startIndex = 0;

    if (resumeContext && resumeContext.enabled && !resumeContext.gateOpen) {
      if (!prefixMatchesResume(combo, depth)) return;

      const resumeValue = normalizeText(resumeContext.resumeAfterCombo?.[group.label] || '');
      const idx = optionTexts.findIndex(text => normalizeText(text) === resumeValue);
      if (idx >= 0) {
        startIndex = idx;
        if (idx > 0) log(`续采跳过 ${group.label} 的前 ${idx} 个选项，直接定位到：${resumeValue}`);
      } else {
        resumeContext.gateOpen = true;
        log(`续采断点选项不存在：${group.label}=${resumeValue}，改用跳过已完成组合模式`);
      }
    }

    log(`遍历字段：${group.label}，选项数：${optionTexts.length}`);

    for (let i = startIndex; i < optionTexts.length; i++) {
      if (stopped) return;

      const text = optionTexts[i];
      const freshOption = findOptionElement(depth, text);
      if (!freshOption) {
        log(`选项已不存在，跳过：${group.label}=${text}`);
        continue;
      }

      if (!isActiveOption(freshOption)) {
        await clickAndWait(freshOption, `${group.label}=${text}`, { groupEl: getBySelector(group.selector) });
      } else {
        log(`当前已选中：${group.label}=${text}`);
      }

      await traverseGroups(depth + 1, { ...combo, [group.label]: text });
    }
  }

  function collectAllHeaders(records) {
    const preferred = state.groups.map(g => g.label).filter(h => h && !HIDDEN_EXPORT_FIELDS.has(h));
    const all = [];

    for (const h of preferred) if (!all.includes(h)) all.push(h);
    for (const row of records) {
      for (const key of Object.keys(row)) {
        if (HIDDEN_EXPORT_FIELDS.has(key)) continue;
        if (!all.includes(key)) all.push(key);
      }
    }
    return all;
  }

  function exportXLSX() {
    if (!state.records.length) {
      log('暂无数据可导出');
      return;
    }

    const cleanRecords = state.records.map(removeHiddenExportFields);
    const headers = collectAllHeaders(cleanRecords);
    if (!headers.length) {
      log('暂无有效字段可导出');
      return;
    }

    const rows = [headers, ...cleanRecords.map(row => headers.map(h => String(row[h] ?? '')))];
    const blob = createXlsxBlob(rows, '采集结果');
    const filename = `表格采集_${formatFileTime(new Date())}_${cleanRecords.length}行.xlsx`;
    downloadBlob(blob, filename);

    state.records = cleanRecords;
    saveState();
    log(`已导出：${filename}`);
  }

  function formatFileTime(d) {
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function xmlEscape(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  function columnName(index) {
    let name = '';
    let n = index + 1;
    while (n > 0) {
      const mod = (n - 1) % 26;
      name = String.fromCharCode(65 + mod) + name;
      n = Math.floor((n - mod) / 26);
    }
    return name;
  }

  function createXlsxBlob(rows, sheetName) {
    const safeSheetName = String(sheetName || 'Sheet1').replace(/[\\/\?\*\[\]:]/g, '').slice(0, 31) || 'Sheet1';
    const maxCols = Math.max(1, ...rows.map(r => r.length));
    const maxRows = Math.max(1, rows.length);
    const ref = `A1:${columnName(maxCols - 1)}${maxRows}`;

    const colWidths = [];
    for (let c = 0; c < maxCols; c++) {
      let maxLen = 8;
      for (let r = 0; r < Math.min(rows.length, 3000); r++) {
        maxLen = Math.max(maxLen, String(rows[r][c] ?? '').length);
      }
      colWidths.push(Math.min(Math.max(maxLen + 2, 10), 42));
    }

    const colsXml = `<cols>${colWidths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols>`;

    const sheetData = rows.map((row, rIdx) => {
      const cells = [];
      for (let cIdx = 0; cIdx < maxCols; cIdx++) {
        const value = row[cIdx] == null ? '' : String(row[cIdx]);
        const cellRef = `${columnName(cIdx)}${rIdx + 1}`;
        cells.push(`<c r="${cellRef}" t="inlineStr"><is><t>${xmlEscape(value)}</t></is></c>`);
      }
      return `<row r="${rIdx + 1}">${cells.join('')}</row>`;
    }).join('');

    const worksheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <dimension ref="${ref}"/>
  <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
  ${colsXml}
  <sheetData>${sheetData}</sheetData>
</worksheet>`;

    const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="${xmlEscape(safeSheetName)}" sheetId="1" r:id="rId1"/></sheets>
</workbook>`;

    const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>`;

    const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

    const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>`;

    const files = [
      { name: '[Content_Types].xml', data: contentTypes },
      { name: '_rels/.rels', data: rootRels },
      { name: 'xl/workbook.xml', data: workbookXml },
      { name: 'xl/_rels/workbook.xml.rels', data: workbookRels },
      { name: 'xl/worksheets/sheet1.xml', data: worksheetXml }
    ];

    return new Blob([createZip(files)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }

  const crcTable = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[i] = c >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) crc = crcTable[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }

  function encodeUtf8(text) {
    return new TextEncoder().encode(text);
  }

  function dosDateTime(date) {
    const year = Math.max(1980, date.getFullYear());
    const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
    const day = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
    return { time, day };
  }

  function writeU16(arr, value) {
    arr.push(value & 0xff, (value >>> 8) & 0xff);
  }

  function writeU32(arr, value) {
    arr.push(value & 0xff, (value >>> 8) & 0xff, (value >>> 16) & 0xff, (value >>> 24) & 0xff);
  }

  function appendBytes(arr, bytes) {
    for (const b of bytes) arr.push(b);
  }

  function createZip(files) {
    const out = [];
    const central = [];
    let offset = 0;
    const now = dosDateTime(new Date());

    for (const file of files) {
      const nameBytes = encodeUtf8(file.name);
      const dataBytes = encodeUtf8(file.data);
      const crc = crc32(dataBytes);
      const localOffset = offset;

      const local = [];
      writeU32(local, 0x04034b50);
      writeU16(local, 20);
      writeU16(local, 0x0800);
      writeU16(local, 0);
      writeU16(local, now.time);
      writeU16(local, now.day);
      writeU32(local, crc);
      writeU32(local, dataBytes.length);
      writeU32(local, dataBytes.length);
      writeU16(local, nameBytes.length);
      writeU16(local, 0);
      appendBytes(local, nameBytes);
      appendBytes(local, dataBytes);
      appendBytes(out, local);
      offset += local.length;

      const cen = [];
      writeU32(cen, 0x02014b50);
      writeU16(cen, 20);
      writeU16(cen, 20);
      writeU16(cen, 0x0800);
      writeU16(cen, 0);
      writeU16(cen, now.time);
      writeU16(cen, now.day);
      writeU32(cen, crc);
      writeU32(cen, dataBytes.length);
      writeU32(cen, dataBytes.length);
      writeU16(cen, nameBytes.length);
      writeU16(cen, 0);
      writeU16(cen, 0);
      writeU16(cen, 0);
      writeU16(cen, 0);
      writeU32(cen, 0);
      writeU32(cen, localOffset);
      appendBytes(cen, nameBytes);
      appendBytes(central, cen);
    }

    const centralOffset = offset;
    appendBytes(out, central);
    offset += central.length;

    const end = [];
    writeU32(end, 0x06054b50);
    writeU16(end, 0);
    writeU16(end, 0);
    writeU16(end, files.length);
    writeU16(end, files.length);
    writeU32(end, central.length);
    writeU32(end, centralOffset);
    writeU16(end, 0);
    appendBytes(out, end);

    return new Uint8Array(out);
  }

  function injectGlobalPickStyle() {
    if (globalStyleInserted) return;
    globalStyleInserted = true;
    const style = document.createElement('style');
    style.id = 'cascade-table-crawler-global-style';
    style.textContent = `
      .ctc-pick-mask {
        outline: 3px solid #ef4444 !important;
        outline-offset: 2px !important;
        background: rgba(239, 68, 68, .08) !important;
        cursor: crosshair !important;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function createPickOverlay() {
    let overlay = document.getElementById('ctc-pick-overlay');
    if (overlay) return overlay;

    overlay = document.createElement('div');
    overlay.id = 'ctc-pick-overlay';
    overlay.style.cssText = [
      'position:fixed',
      'z-index:2147483646',
      'pointer-events:none',
      'border:3px solid #ef4444',
      'box-shadow:0 0 0 9999px rgba(15,23,42,.08),0 10px 30px rgba(239,68,68,.24)',
      'background:rgba(239,68,68,.06)',
      'border-radius:8px',
      'transition:all .045s linear',
      'display:none'
    ].join(';');

    const label = document.createElement('div');
    label.id = 'ctc-pick-overlay-label';
    label.textContent = '点击选择此区域';
    label.style.cssText = [
      'position:absolute',
      'left:0',
      'top:-28px',
      'height:24px',
      'line-height:24px',
      'padding:0 8px',
      'border-radius:7px',
      'background:#ef4444',
      'color:#fff',
      'font-size:12px',
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif',
      'white-space:nowrap'
    ].join(';');
    overlay.appendChild(label);

    document.documentElement.appendChild(overlay);
    return overlay;
  }

  function updatePickOverlay(target) {
    if (!target || !(target instanceof Element)) return;
    const overlay = createPickOverlay();
    const rect = target.getBoundingClientRect();
    const left = Math.max(2, rect.left);
    const top = Math.max(2, rect.top);
    const right = Math.min(window.innerWidth - 2, rect.right);
    const bottom = Math.min(window.innerHeight - 2, rect.bottom);
    const width = Math.max(4, right - left);
    const height = Math.max(4, bottom - top);

    overlay.style.display = 'block';
    overlay.style.left = `${left}px`;
    overlay.style.top = `${top}px`;
    overlay.style.width = `${width}px`;
    overlay.style.height = `${height}px`;
  }

  function removePickOverlay() {
    const overlay = document.getElementById('ctc-pick-overlay');
    if (overlay) overlay.remove();
  }

  function pickElement(tip, callback, options = {}) {
    injectGlobalPickStyle();
    log(tip);
    uiOpen = false;
    render();

    const oldCursor = document.body.style.cursor;
    document.body.style.cursor = 'crosshair';
    let current = null;

    function getTarget(raw) {
      if (!raw || raw.closest(`#${EXT_ID}`)) return null;
      if (typeof options.resolveTarget === 'function') return options.resolveTarget(raw) || raw;
      return raw;
    }

    function onMove(e) {
      const target = getTarget(e.target);
      if (!target) return;
      if (current && current !== target) current.classList.remove('ctc-pick-mask');
      current = target;
      current.classList.add('ctc-pick-mask');
      updatePickOverlay(current);
      e.preventDefault();
      e.stopPropagation();
    }

    function onClick(e) {
      const target = getTarget(e.target);
      if (!target) return;
      e.preventDefault();
      e.stopPropagation();
      cleanup();
      uiOpen = true;
      callback(target);
      render();
    }

    function onKey(e) {
      if (e.key === 'Escape') {
        cleanup();
        uiOpen = true;
        log('已取消选择');
      }
    }

    function cleanup() {
      document.body.style.cursor = oldCursor;
      if (current) current.classList.remove('ctc-pick-mask');
      removePickOverlay();
      document.removeEventListener('mousemove', onMove, true);
      document.removeEventListener('click', onClick, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('scroll', onScrollOrResize, true);
      window.removeEventListener('resize', onScrollOrResize, true);
    }

    function onScrollOrResize() {
      if (current) updatePickOverlay(current);
    }

    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('scroll', onScrollOrResize, true);
    window.addEventListener('resize', onScrollOrResize, true);
  }

  function createUI() {
    if (document.getElementById(EXT_ID)) return;

    const host = document.createElement('div');
    host.id = EXT_ID;
    document.documentElement.appendChild(host);
    shadowRoot = host.attachShadow({ mode: 'open' });
    render();
  }

  function styles() {
    return `
      :host { all: initial; }
      * { box-sizing: border-box; }
      .ctc-font {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
        color: #111827;
        font-size: 13px;
      }
      .ctc-fab {
        position: fixed;
        right: 18px;
        bottom: 22px;
        z-index: 2147483647;
        border: none;
        border-radius: 999px;
        padding: 10px 15px;
        background: linear-gradient(135deg, #2563eb, #14b8a6);
        color: #fff;
        box-shadow: 0 12px 30px rgba(37,99,235,.28);
        cursor: pointer;
        font-weight: 800;
        letter-spacing: .2px;
      }
      .ctc-panel {
        position: fixed;
        right: 18px;
        top: 48px;
        z-index: 2147483647;
        width: min(540px, calc(100vw - 36px));
        max-height: calc(100vh - 72px);
        display: flex;
        flex-direction: column;
        background: rgba(255,255,255,.98);
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        box-shadow: 0 24px 70px rgba(15,23,42,.20);
        overflow: hidden;
        backdrop-filter: blur(8px);
      }
      .ctc-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 14px;
        background: linear-gradient(135deg, #eff6ff, #f8fafc 58%, #ecfeff);
        border-bottom: 1px solid #e5e7eb;
      }
      .ctc-title { font-size: 15px; font-weight: 800; }
      .ctc-subtitle {
        margin-top: 2px;
        color: #6b7280;
        font-size: 12px;
        max-width: 390px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .ctc-close {
        border: 1px solid #d1d5db;
        background: #fff;
        color: #374151;
        border-radius: 8px;
        height: 30px;
        padding: 0 10px;
        cursor: pointer;
      }
      .ctc-tabs {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
        padding: 8px 10px;
        background: #fff;
        border-bottom: 1px solid #e5e7eb;
      }
      .ctc-tab {
        border: 1px solid #e5e7eb;
        background: #f8fafc;
        color: #334155;
        border-radius: 999px;
        padding: 7px 8px;
        cursor: pointer;
        white-space: nowrap;
        font-weight: 700;
        font-size: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
      }
      .ctc-tab .step-num {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 18px;
        height: 18px;
        border-radius: 5px;
        background: rgba(15,23,42,.08);
        font-size: 10px;
        font-weight: 800;
        color: #64748b;
      }
      .ctc-tab.active {
        background: #0f172a;
        border-color: #0f172a;
        color: #fff;
        box-shadow: 0 6px 18px rgba(15,23,42,.18);
      }
      .ctc-tab.active .step-num {
        background: rgba(255,255,255,.18);
        color: #f1f5f9;
      }
      .ctc-body {
        overflow: auto;
        padding: 10px;
        background: #f8fafc;
      }
      .ctc-card {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 10px;
        background: #fff;
        margin-bottom: 9px;
        box-shadow: 0 6px 18px rgba(15,23,42,.035);
      }
      .ctc-card.gray { background: #f9fafb; }
      .ctc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
      .ctc-grid3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }
      label { display: block; color: #4b5563; font-size: 12px; margin-bottom: 4px; }
      input, textarea, select {
        width: 100%;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        padding: 7px 8px;
        font-size: 12px;
        outline: none;
        background: #fff;
        color: #111827;
      }
      textarea { min-height: 64px; resize: vertical; }
      input:focus, textarea:focus { border-color: #1677ff; box-shadow: 0 0 0 2px rgba(22,119,255,.12); }
      button {
        border: 1px solid #d1d5db;
        background: #fff;
        color: #111827;
        border-radius: 8px;
        padding: 7px 9px;
        cursor: pointer;
        font-size: 12px;
      }
      button:hover { background: #f3f7ff; }
      button.primary { background: #1677ff; border-color: #1677ff; color: #fff; }
      button.success { background: #16a34a; border-color: #16a34a; color: #fff; }
      button.danger { background: #ef4444; border-color: #ef4444; color: #fff; }
      button.warn { background: #f97316; border-color: #f97316; color: #fff; }
      button.ghost { background: #f9fafb; }
      .ctc-stat {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 7px;
      }
      .ctc-stat-item {
        border: 1px solid #e5e7eb;
        background: linear-gradient(180deg, #ffffff, #f8fafc);
        border-radius: 12px;
        padding: 8px;
        text-align: center;
      }
      .ctc-stat-item b { display: block; font-size: 16px; margin-bottom: 1px; }
      .ctc-muted { color: #6b7280; font-size: 12px; line-height: 1.6; }
      .ctc-row { margin-bottom: 10px; }
      .ctc-section-title { font-size: 12px; font-weight: 800; color: #0f172a; margin-bottom: 8px; display:flex; align-items:center; justify-content:space-between; }
      .ctc-compact-actions { display:grid; grid-template-columns: repeat(4, 1fr); gap: 7px; }
      .ctc-path { color:#64748b; font-size:11px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

      .ctc-group {
        display: grid;
        grid-template-columns: 84px 1fr 118px;
        gap: 6px;
        align-items: center;
        padding: 6px;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        margin-bottom: 6px;
        background: #fff;
      }
      .ctc-actions { display: flex; gap: 4px; justify-content: flex-end; }
      .ctc-log {
        height: 280px;
        overflow: auto;
        background: #0b1020;
        color: #d8f8d8;
        border-radius: 10px;
        padding: 10px;
        white-space: pre-wrap;
        font-family: Consolas, Monaco, monospace;
        font-size: 11px;
        line-height: 1.5;
      }
      .ctc-table-wrap { max-height: 330px; overflow: auto; border: 1px solid #e5e7eb; border-radius: 10px; }
      table { border-collapse: collapse; width: max-content; min-width: 100%; font-size: 12px; }
      th, td { border: 1px solid #e5e7eb; padding: 6px 8px; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      th { position: sticky; top: 0; background: #f3f4f6; z-index: 1; }
      .ctc-badge { display: inline-flex; align-items: center; border-radius: 999px; padding: 2px 8px; background: #eef2ff; color: #3730a3; font-size: 12px; }

      .ctc-flow-step {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 8px 0;
        position: relative;
      }
      .ctc-flow-step:not(:last-child)::after {
        content: '';
        position: absolute;
        left: 15px;
        top: 30px;
        bottom: -2px;
        width: 1.5px;
        background: linear-gradient(to bottom, #e2e8f0, transparent);
      }
      .ctc-flow-num {
        flex-shrink: 0;
        width: 30px;
        height: 30px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 13px;
        color: #0f172a;
        border: 1.5px solid #e2e8f0;
        background: #f8fafc;
      }
      .ctc-flow-content { flex: 1; }
      .ctc-flow-content .ctc-flow-title { font-size: 12.5px; font-weight: 700; color: #0f172a; margin-bottom: 6px; }
      .ctc-flow-content .ctc-flow-desc { font-size: 11.5px; color: #64748b; margin-bottom: 8px; line-height: 1.5; }

      @media (max-width: 760px) {
        .ctc-grid, .ctc-grid3, .ctc-stat { grid-template-columns: 1fr; }
        .ctc-group { grid-template-columns: 1fr; }
      }
    `;
  }

  function render() {
    if (!shadowRoot) return;

    const tabs = [
      ['flow', '操作流程', '1'],
      ['fields', '字段配置', '2'],
      ['table', '表格选择', '3'],
      ['crawl', '数据采集', '4'],
      ['export', '数据导出', '5'],
      ['advanced', '高级设置', '6']
    ];

    const html = `
      <style>${styles()}</style>
      <div class="ctc-font">
        ${uiOpen ? `
          <div class="ctc-panel">
            <div class="ctc-head">
              <div>
                <div class="ctc-title">表格采集器</div>
                <div class="ctc-subtitle">${escapeHtml(location.href)}</div>
              </div>
              <button class="ctc-close" data-action="toggle">收起</button>
            </div>
            <div class="ctc-tabs">
              ${tabs.map(([key, label, num]) => `<button class="ctc-tab ${activeTab === key ? 'active' : ''}" data-tab="${key}"><span class="step-num">${num}</span>${label}</button>`).join('')}
            </div>
            <div class="ctc-body">
              ${renderTabContent()}
            </div>
          </div>
        ` : ''}
      </div>
    `;

    shadowRoot.innerHTML = html;
    bindUIEvents();
  }

  function renderTabContent() {
    if (activeTab === 'flow') return renderFlowTabNew();
    if (activeTab === 'fields') return renderFieldsTabNew();
    if (activeTab === 'table') return renderTableTabNew();
    if (activeTab === 'crawl') return renderCrawlTabNew();
    if (activeTab === 'export') return renderExportTabNew();
    if (activeTab === 'advanced') return renderAdvancedTabNew();
    return renderFlowTabNew();
  }

  function renderStats() {
    return `
      <div class="ctc-card gray">
        <div class="ctc-stat">
          <div class="ctc-stat-item"><b>${state.records.length}</b><span>已采集行</span></div>
          <div class="ctc-stat-item"><b>${state.completedKeys.length}</b><span>完成组合</span></div>
          <div class="ctc-stat-item"><b>${state.groups.length}</b><span>字段组</span></div>
          <div class="ctc-stat-item"><b>${running ? '运行中' : '空闲'}</b><span>状态</span></div>
        </div>
      </div>
    `;
  }

  function renderFlowTabNew() {
    return `
      <div class="ctc-card gray">
        <div class="ctc-section-title">操作流程</div>
        <div class="ctc-flow-step">
          <div class="ctc-flow-num">1</div>
          <div class="ctc-flow-content">
            <div class="ctc-flow-title">打开插件面板</div>
            <div class="ctc-flow-desc">点击浏览器工具栏里的“表格采集器”图标，按需打开本面板。页面右下角不再常驻悬浮按钮。</div>
          </div>
        </div>
        <div class="ctc-flow-step">
          <div class="ctc-flow-num">2</div>
          <div class="ctc-flow-content">
            <div class="ctc-flow-title">配置字段</div>
            <div class="ctc-flow-desc">在“字段配置”页选择筛选区域，自动识别或手动添加省份、年份、科类、类型等字段组。</div>
            <button data-tab="fields">进入字段配置</button>
          </div>
        </div>
        <div class="ctc-flow-step">
          <div class="ctc-flow-num">3</div>
          <div class="ctc-flow-content">
            <div class="ctc-flow-title">选择表格与分页</div>
            <div class="ctc-flow-desc">在“表格选择”页框选真实表格区域。若表格底部有下一页按钮，可开启分页采集并选择下一页按钮。</div>
            <button data-tab="table">进入表格选择</button>
          </div>
        </div>
        <div class="ctc-flow-step">
          <div class="ctc-flow-num">4</div>
          <div class="ctc-flow-content">
            <div class="ctc-flow-title">采集与导出</div>
            <div class="ctc-flow-desc">在“数据采集”页开始、继续或停止采集；在“数据导出”页预览结果并导出 XLSX。</div>
            <button class="primary" data-tab="crawl">进入数据采集</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderFieldsTabNew() {
    const groupsHtml = state.groups.length
      ? state.groups.map((g, i) => `
        <div class="ctc-group" data-index="${i}">
          <input class="ctc-group-label" data-index="${i}" value="${escapeHtml(g.label || `字段${i + 1}`)}" title="导出字段名">
          <input value="${escapeHtml(g.selector || '')}" readonly title="${escapeHtml(g.selector || '')}">
          <div class="ctc-actions">
            <button data-action="move-up" data-index="${i}">上</button>
            <button data-action="move-down" data-index="${i}">下</button>
            <button class="danger" data-action="remove-group" data-index="${i}">删</button>
          </div>
        </div>`).join('')
      : '<div class="ctc-muted">暂无字段组。建议先选择筛选区域并自动识别，或手动添加。</div>';

    return `
      <div class="ctc-card">
        <div class="ctc-section-title">快速操作</div>
        <div class="ctc-grid3">
          <button data-action="pick-filter-root">选择筛选区域</button>
          <button class="primary" data-action="auto-detect">自动识别字段组</button>
          <button data-action="add-group">手动添加字段组</button>
          <button class="danger" data-action="clear-groups">清空字段组</button>
        </div>
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">字段组列表</div>
        <div class="ctc-muted" style="margin-bottom:8px;">从上到下就是遍历顺序。若识别偏多，先缩小筛选区域后再识别。</div>
        ${groupsHtml}
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">其他配置</div>
        <div class="ctc-row">
          <label>自动识别字段关键词，按顺序识别</label>
          <input id="ctc-keywords" data-sync="1" value="${escapeHtml(state.keywords)}">
        </div>
        <div class="ctc-grid">
          <div>
            <label>汇总选项处理</label>
            <select id="ctc-summary-mode" data-sync="1">
              <option value="skip" ${(state.summaryOptionMode || (state.skipAllOption ? 'skip' : 'keep')) === 'skip' ? 'selected' : ''}>跳过全部/不限/请选择</option>
              <option value="keep" ${(state.summaryOptionMode || (state.skipAllOption ? 'skip' : 'keep')) === 'keep' ? 'selected' : ''}>保留汇总选项</option>
              <option value="only" ${(state.summaryOptionMode || (state.skipAllOption ? 'skip' : 'keep')) === 'only' ? 'selected' : ''}>只采集汇总选项</option>
            </select>
          </div>
          <div>
            <label>只采集汇总选项的字段组</label>
            <input id="ctc-only-all-groups" data-sync="1" value="${escapeHtml(state.onlyAllGroupLabels || '')}" placeholder="例如：科类,类别；* 表示全部字段">
          </div>
        </div>
        <div class="ctc-muted" style="margin-top:8px;">“只采集汇总选项”适用于某些字段选“全部/不限”即可得到完整表格的页面。</div>
        <div class="ctc-row" style="margin-top:10px;">
          <button class="primary" data-action="save-config">保存配置</button>
        </div>
      </div>

      <div class="ctc-card gray">
        <div class="ctc-section-title">当前选择器</div>
        <label>筛选区域</label>
        <textarea readonly>${escapeHtml(state.filterRootSelector || '未指定，默认从整个页面自动识别')}</textarea>
      </div>
    `;
  }

  function renderTableTabNew() {
    const rows = extractCurrentTableRows();
    const preview = rows.slice(0, 8);

    return `
      <div class="ctc-card">
        <div class="ctc-section-title">表格区域操作</div>
        <div class="ctc-grid">
          <button class="primary" data-action="pick-table">选择表格区域</button>
          <button data-action="test-table">测试当前表格</button>
        </div>
        <div class="ctc-muted" style="margin-top:8px;">点击表格任意单元格即可。新版会优先锁定真实表格或只含标题的最小容器，尽量避免把省份、年份、科类等筛选字段框进去。</div>
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">分页采集</div>
        <div class="ctc-grid">
          <div>
            <label>是否采集分页</label>
            <select id="ctc-pagination-enabled" data-sync="1">
              <option value="false" ${!state.paginationEnabled ? 'selected' : ''}>关闭，只采集当前页</option>
              <option value="true" ${state.paginationEnabled ? 'selected' : ''}>开启，采集每一页</option>
            </select>
          </div>
          <div>
            <label>最大翻页页数</label>
            <input id="ctc-pagination-max-pages" data-sync="1" type="number" value="${state.paginationMaxPages || DEFAULT_STATE.paginationMaxPages}">
          </div>
        </div>
        <div class="ctc-row" style="margin-top:8px;">
          <div class="ctc-grid">
            <button data-action="pick-pagination-next">选择下一页按钮</button>
            <button data-action="clear-pagination-next">清空下一页按钮</button>
          </div>
        </div>
        <label>下一页按钮选择器</label>
        <textarea readonly>${escapeHtml(state.paginationNextSelector || '未指定时自动识别：支持 a / button / li / span / div 等常见下一页标签')}</textarea>
        <div class="ctc-muted" style="margin-top:8px;">如果自动识别不准，手动点击“选择下一页按钮”，选中表格下方的“下一页 / > / › / next”按钮即可。</div>
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">当前选择器</div>
        <label>表格区域</label>
        <textarea readonly>${escapeHtml(state.tableRootSelector || '未指定，默认自动选择当前页面最大表格')}</textarea>
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">表格预览</div>
        <div class="ctc-muted">当前读取到 <b>${rows.length}</b> 行，以下显示前 ${preview.length} 行。</div>
        ${renderRowsPreview(preview)}
      </div>
    `;
  }

  function renderCrawlTabNew() {
    return `
      ${renderStats()}

      <div class="ctc-card">
        <div class="ctc-section-title">采集配置 <span class="ctc-path">${escapeHtml(location.host)}</span></div>
        <div class="ctc-grid">
          <div>
            <label>年份筛选，留空=全部</label>
            <input id="ctc-year-filter" data-sync="1" value="${escapeHtml(state.yearFilter)}" placeholder="例如：2025 或 2025,2024">
          </div>
          <div>
            <label>省份筛选，留空=全部</label>
            <input id="ctc-province-filter" data-sync="1" value="${escapeHtml(state.provinceFilter)}" placeholder="例如：北京 或 北京,天津,河北">
          </div>
        </div>
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">采集操作</div>
        <div class="ctc-compact-actions">
          <button class="primary" data-action="start-fresh">开始采集</button>
          <button class="success" data-action="start-resume">继续采集</button>
          <button class="danger" data-action="stop">停止</button>
          <button class="warn" data-action="export-xlsx">导出 XLSX</button>
        </div>
      </div>

      <div class="ctc-card gray">
        <div class="ctc-section-title">当前状态</div>
        <div class="ctc-muted">字段组：${state.groups.length ? state.groups.map(g => escapeHtml(g.label)).join(' / ') : '未设置'}</div>
        <div class="ctc-muted" style="margin-top:4px;">分页采集：${state.paginationEnabled ? `开启，最大 ${state.paginationMaxPages || DEFAULT_STATE.paginationMaxPages} 页` : '关闭'}</div>
        <div class="ctc-muted" style="margin-top:4px;">断点：${escapeHtml(state.lastCompletedCombo || '无')}</div>
      </div>
    `;
  }

  function renderExportTabNew() {
    const rows = state.records.slice(0, previewLimit);
    const headers = collectAllHeaders(state.records);
    return `
      ${renderStats()}

      <div class="ctc-card">
        <div class="ctc-section-title">导出操作</div>
        <div class="ctc-grid3">
          <button class="warn" data-action="export-xlsx">导出 XLSX</button>
          <button data-action="copy-json">复制 JSON</button>
          <button class="danger" data-action="clear-records">清空结果和进度</button>
        </div>
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">采集结果预览</div>
        <div class="ctc-muted">当前仅预览前 ${Math.min(previewLimit, state.records.length)} / ${state.records.length} 行，导出会导出全部数据。</div>
        ${renderRecordsPreview(headers, rows)}
      </div>

      <div class="ctc-card">
        <div class="ctc-section-title">日志</div>
        <div class="ctc-grid">
          <button data-action="copy-logs">复制日志</button>
          <button class="danger" data-action="clear-logs">清空日志</button>
        </div>
        <div class="ctc-log" style="margin-top:8px; height: 180px;">${escapeHtml(state.logs.slice(0, 100).join('\n'))}</div>
      </div>
    `;
  }

  function renderAdvancedTabNew() {
    return `
      ${renderStats()}

      <div class="ctc-card">
        <div class="ctc-section-title">高级设置</div>
        <div class="ctc-grid">
          <div>
            <label>最小点击延时 ms</label>
            <input id="ctc-min-delay" data-sync="1" type="number" value="${state.minDelay}">
          </div>
          <div>
            <label>最大点击延时 ms</label>
            <input id="ctc-max-delay" data-sync="1" type="number" value="${state.maxDelay}">
          </div>
          <div>
            <label>DOM 稳定等待 ms</label>
            <input id="ctc-stable-ms" data-sync="1" type="number" value="${state.stableMs}">
          </div>
          <div>
            <label>单次超时 ms</label>
            <input id="ctc-timeout-ms" data-sync="1" type="number" value="${state.timeoutMs}">
          </div>
          <div>
            <label>每个表格最多读取行数，0=不限</label>
            <input id="ctc-max-rows" data-sync="1" type="number" value="${state.maxRowsPerTable}">
          </div>
        </div>
        <div class="ctc-row" style="margin-top:10px;">
          <button class="primary" data-action="save-config">保存高级设置</button>
          <button data-action="copy-config">复制配置 JSON</button>
          <button data-action="import-config">导入配置 JSON</button>
          <button data-action="rebuild-progress">重建进度</button>
        </div>
      </div>

      <div class="ctc-card gray">
        <div class="ctc-section-title">当前选择器</div>
        <label>筛选区域</label>
        <textarea readonly>${escapeHtml(state.filterRootSelector || '未指定，默认从整个页面自动识别')}</textarea>
        <label style="margin-top:8px;">表格区域</label>
        <textarea readonly>${escapeHtml(state.tableRootSelector || '未指定，默认自动选择当前页面最大表格')}</textarea>
        <label style="margin-top:8px;">下一页按钮</label>
        <textarea readonly>${escapeHtml(state.paginationNextSelector || '未指定，自动识别下一页按钮')}</textarea>
      </div>
    `;
  }

  function renderRowsPreview(rows) {
    if (!rows.length) return '<div class="ctc-muted">暂无表格预览。</div>';
    const maxCols = Math.max(...rows.map(r => r.length));
    return `
      <div class="ctc-table-wrap">
        <table>
          <tbody>
            ${rows.map(row => `<tr>${Array.from({ length: maxCols }, (_, i) => `<td>${escapeHtml(row[i] ?? '')}</td>`).join('')}</tr>`).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function renderRecordsPreview(headers, records) {
    if (!headers.length || !records.length) return '<div class="ctc-muted">暂无采集结果。</div>';
    return `
      <div class="ctc-table-wrap">
        <table>
          <thead><tr>${headers.map(h => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead>
          <tbody>
            ${records.map(row => `<tr>${headers.map(h => `<td title="${escapeHtml(row[h] ?? '')}">${escapeHtml(row[h] ?? '')}</td>`).join('')}</tr>`).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function bindUIEvents() {
    if (!shadowRoot) return;

    shadowRoot.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        render();
      });
    });

    shadowRoot.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => handleAction(btn.dataset.action, btn.dataset));
    });

    shadowRoot.querySelectorAll('.ctc-group-label').forEach(input => {
      input.addEventListener('change', e => {
        const idx = Number(e.target.dataset.index);
        if (!state.groups[idx]) return;
        state.groups[idx].label = normalizeText(e.target.value) || `字段${idx + 1}`;
        state.completedKeys = [];
        state.lastCompletedCombo = '';
        state.resumeAfterCombo = null;
        saveState();
        log('字段名称已变更，已清空采集进度；已有结果未删除');
      });
    });


    shadowRoot.querySelectorAll('[data-sync="1"]').forEach(input => {
      const eventName = input.tagName === 'SELECT' ? 'change' : 'input';
      input.addEventListener(eventName, () => syncInputsFromUI());
    });
  }

  function syncInputsFromUI() {
    if (!shadowRoot) return;

    const yearFilter = shadowRoot.querySelector('#ctc-year-filter');
    const provinceFilter = shadowRoot.querySelector('#ctc-province-filter');
    const keywords = shadowRoot.querySelector('#ctc-keywords');
    const onlyAllGroups = shadowRoot.querySelector('#ctc-only-all-groups');
    const minDelay = shadowRoot.querySelector('#ctc-min-delay');
    const maxDelay = shadowRoot.querySelector('#ctc-max-delay');
    const stableMs = shadowRoot.querySelector('#ctc-stable-ms');
    const timeoutMs = shadowRoot.querySelector('#ctc-timeout-ms');
    const maxRows = shadowRoot.querySelector('#ctc-max-rows');
    const summaryMode = shadowRoot.querySelector('#ctc-summary-mode');
    const paginationEnabled = shadowRoot.querySelector('#ctc-pagination-enabled');
    const paginationMaxPages = shadowRoot.querySelector('#ctc-pagination-max-pages');

    if (yearFilter) state.yearFilter = yearFilter.value || '';
    if (provinceFilter) state.provinceFilter = provinceFilter.value || '';
    if (keywords) state.keywords = keywords.value || DEFAULT_STATE.keywords;
    if (onlyAllGroups) state.onlyAllGroupLabels = onlyAllGroups.value || '';
    if (minDelay) state.minDelay = Number(minDelay.value) || DEFAULT_STATE.minDelay;
    if (maxDelay) state.maxDelay = Number(maxDelay.value) || DEFAULT_STATE.maxDelay;
    if (stableMs) state.stableMs = Number(stableMs.value) || DEFAULT_STATE.stableMs;
    if (timeoutMs) state.timeoutMs = Number(timeoutMs.value) || DEFAULT_STATE.timeoutMs;
    if (maxRows) state.maxRowsPerTable = Number(maxRows.value) || 0;
    if (summaryMode) {
      state.summaryOptionMode = summaryMode.value || 'skip';
      state.skipAllOption = state.summaryOptionMode === 'skip';
    }
    if (paginationEnabled) state.paginationEnabled = paginationEnabled.value === 'true';
    if (paginationMaxPages) state.paginationMaxPages = Math.max(1, Number(paginationMaxPages.value) || DEFAULT_STATE.paginationMaxPages);

    saveState();
  }

  async function handleAction(action, dataset = {}) {
    switch (action) {
      case 'toggle':
        uiOpen = !uiOpen;
        render();
        break;
      case 'save-config':
        syncInputsFromUI();
        log('配置已保存');
        break;
      case 'copy-config':
        await copyText(JSON.stringify({ ...state, records: [], logs: [], completedKeys: [], lastCompletedCombo: '', resumeAfterCombo: null }, null, 2));
        log('已复制当前页面配置 JSON，不包含采集结果');
        break;
      case 'import-config':
        importConfig();
        break;
      case 'auto-detect':
        syncInputsFromUI();
        autoDetectGroups();
        break;
      case 'add-group':
        pickElement('请选择字段组外层，例如"省份：北京 天津..."这一整行', el => {
          const selector = cssPath(el);
          const labelDefault = detectGroupLabel(el, state.groups.length);
          const label = window.prompt('请输入该字段组的导出字段名：', labelDefault) || labelDefault;
          state.groups.push({ label: normalizeText(label), selector });
          state.completedKeys = [];
          state.lastCompletedCombo = '';
          state.resumeAfterCombo = null;
          saveState();
          log(`已添加字段组：${label}`);
        });
        break;
      case 'pick-filter-root':
        pickElement('请选择筛选区域外层。不选也可以默认从全页面识别', el => {
          state.filterRootSelector = cssPath(el);
          state.completedKeys = [];
          state.lastCompletedCombo = '';
          state.resumeAfterCombo = null;
          saveState();
          log('已选择筛选区域');
        });
        break;
      case 'pick-table':
        pickElement('请选择表格区域：点击表格任意单元格即可，插件会优先定位真实表格，避免框入筛选字段', el => {
          const tableEl = resolveTablePickTarget(el, { includeTitle: true });
          state.tableRootSelector = cssPath(tableEl);
          saveState();
          log(`已选择表格区域：${tableEl.tagName.toLowerCase()}${tableEl.querySelector?.('table') ? '（含标题/外层容器）' : ''}`);
        }, { resolveTarget: raw => resolveTablePickTarget(raw, { includeTitle: true }) });
        break;
      case 'pick-pagination-next':
        syncInputsFromUI();
        pickElement('请选择表格下方的下一页按钮，例如“下一页 / > / › / next”', el => {
          const target = resolvePaginationClickTarget(el);
          state.paginationNextSelector = cssPath(target);
          state.paginationEnabled = true;
          saveState();
          log('已选择下一页按钮，并开启分页采集');
        }, { resolveTarget: raw => resolvePaginationClickTarget(raw) });
        break;
      case 'clear-pagination-next':
        state.paginationNextSelector = '';
        saveState();
        log('已清空下一页按钮选择器；开启分页时将尝试自动识别');
        render();
        break;
      case 'clear-groups':
        if (window.confirm('确定清空字段组？已有采集结果不会删除，但进度会清空。')) {
          state.groups = [];
          state.completedKeys = [];
          state.lastCompletedCombo = '';
          state.resumeAfterCombo = null;
          saveState();
          log('已清空字段组和进度');
        }
        break;
      case 'move-up':
        moveGroup(Number(dataset.index), -1);
        break;
      case 'move-down':
        moveGroup(Number(dataset.index), 1);
        break;
      case 'remove-group':
        removeGroup(Number(dataset.index));
        break;
      case 'test-table':
        testTable();
        break;
      case 'start-fresh':
        startCrawler('fresh');
        break;
      case 'start-resume':
        startCrawler('resume');
        break;
      case 'stop':
        if (!running) {
          log('当前没有运行中的采集任务');
        } else {
          stopped = true;
          log('已请求停止，当前筛选组合完成后会停止；之后可继续采集');
        }
        break;
      case 'export-xlsx':
        exportXLSX();
        break;
      case 'clear-records':
        if (window.confirm('确定清空已采集结果和进度？')) {
          resetProgressAndRecords();
          log('已清空采集结果和进度');
        }
        break;
      case 'rebuild-progress':
        rebuildCompletedKeysFromRecords();
        log(`已从当前结果重建进度：${state.completedKeys.length} 个组合`);
        break;
      case 'copy-json':
        await copyText(JSON.stringify(state.records, null, 2));
        log('已复制 JSON 到剪贴板');
        break;
      case 'copy-logs':
        await copyText(state.logs.join('\n'));
        log('已复制日志');
        break;
      case 'clear-logs':
        state.logs = [];
        saveState();
        render();
        break;
      default:
        break;
    }
  }

  function moveGroup(index, direction) {
    const target = index + direction;
    if (index < 0 || target < 0 || index >= state.groups.length || target >= state.groups.length) return;
    const [item] = state.groups.splice(index, 1);
    state.groups.splice(target, 0, item);
    state.completedKeys = [];
    state.lastCompletedCombo = '';
    state.resumeAfterCombo = null;
    saveState();
    log('字段组顺序已调整，已清空采集进度；已有结果未删除');
  }

  function removeGroup(index) {
    if (!state.groups[index]) return;
    const label = state.groups[index].label;
    state.groups.splice(index, 1);
    state.completedKeys = [];
    state.lastCompletedCombo = '';
    state.resumeAfterCombo = null;
    saveState();
    log(`已删除字段组：${label}；已清空采集进度，结果未删除`);
  }

  function testTable() {
    const rows = extractCurrentTableRows();
    log(`当前表格测试：读取到 ${rows.length} 行`);
    console.table(rows.slice(0, 20));
    render();
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (err) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
  }

  function importConfig() {
    const raw = window.prompt('请粘贴配置 JSON：');
    if (!raw) return;

    try {
      const parsed = JSON.parse(raw);
      const keepRecords = state.records;
      const keepLogs = state.logs;
      state = normalizeLoadedState({ ...state, ...parsed });
      state.records = keepRecords;
      state.logs = keepLogs;
      state.completedKeys = [];
      state.lastCompletedCombo = '';
      state.resumeAfterCombo = null;
      saveState();
      log('配置已导入，采集进度已清空，已有结果保留');
    } catch (err) {
      log(`配置导入失败：${err.message || err}`);
    }
  }

  function ensureUI() {
    if (!shadowRoot) createUI();
  }

  function openPanel() {
    ensureUI();
    uiOpen = true;
    if (!activeTab) activeTab = 'flow';
    render();
  }

  function togglePanel() {
    ensureUI();
    uiOpen = !uiOpen;
    if (uiOpen && !activeTab) activeTab = 'flow';
    render();
  }

  function installMessageBridge() {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.onMessage) return;
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || !message.type) return;
      if (message.type === 'CTC_PING') {
        sendResponse?.({ ok: true });
        return true;
      }
      if (message.type === 'CTC_OPEN_PANEL') {
        openPanel();
        sendResponse?.({ ok: true });
        return true;
      }
      if (message.type === 'CTC_TOGGLE_PANEL') {
        togglePanel();
        sendResponse?.({ ok: true });
        return true;
      }
    });
  }

  async function init() {
    await loadState();
    installMessageBridge();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
